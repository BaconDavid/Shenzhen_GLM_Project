var styles = [ {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.2",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "default",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "shape" : "ellipse",
      "border-opacity" : 1.0,
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "color" : "rgb(0,0,0)",
      "background-opacity" : 1.0,
      "height" : 35.0,
      "text-opacity" : 1.0,
      "text-valign" : "center",
      "text-halign" : "center",
      "font-size" : 16,
      "background-color" : "rgb(137,208,245)",
      "width" : 75.0,
      "border-width" : 0.0,
      "border-color" : "rgb(204,204,204)",
      "content" : "data(name)"
    }
  }, {
    "selector" : "node[degree_layout > 48]",
    "css" : {
      "color" : "rgb(68,1,84)"
    }
  }, {
    "selector" : "node[degree_layout = 48]",
    "css" : {
      "color" : "rgb(68,2,86)"
    }
  }, {
    "selector" : "node[degree_layout > 24][degree_layout < 48]",
    "css" : {
      "color" : "mapData(degree_layout,24,48,rgb(33,145,140),rgb(68,2,86))"
    }
  }, {
    "selector" : "node[degree_layout > 1][degree_layout < 24]",
    "css" : {
      "color" : "mapData(degree_layout,1,24,rgb(251,231,35),rgb(33,145,140))"
    }
  }, {
    "selector" : "node[degree_layout = 1]",
    "css" : {
      "color" : "rgb(251,231,35)"
    }
  }, {
    "selector" : "node[degree_layout < 1]",
    "css" : {
      "color" : "rgb(253,231,37)"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,0)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "width" : 2.0,
      "color" : "rgb(0,0,0)",
      "line-style" : "solid",
      "content" : "",
      "opacity" : 1.0,
      "line-color" : "rgb(132,132,132)",
      "target-arrow-color" : "rgb(0,0,0)",
      "target-arrow-shape" : "none",
      "text-opacity" : 1.0,
      "font-size" : 10,
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "font-family" : "Dialog.plain",
      "font-weight" : "normal"
    }
  }, {
    "selector" : "edge[Count_normalized > 8.97]",
    "css" : {
      "width" : 1.0
    }
  }, {
    "selector" : "edge[Count_normalized = 8.97]",
    "css" : {
      "width" : 10.8
    }
  }, {
    "selector" : "edge[Count_normalized > 3][Count_normalized < 8.97]",
    "css" : {
      "width" : "mapData(Count_normalized,3,8.97,0.0864000015258789,10.8)"
    }
  }, {
    "selector" : "edge[Count_normalized = 3]",
    "css" : {
      "width" : 0.0864000015258789
    }
  }, {
    "selector" : "edge[Count_normalized < 3]",
    "css" : {
      "width" : 1.0
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
} ]