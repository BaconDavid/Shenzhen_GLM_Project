var networks = {"co_occurrence_symmetric_k_13_fisher_th_0_0001.csv(4)": {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.2",
  "target_cytoscapejs_version" : "~2.1",
  "data" : {
    "shared_name" : "co_occurrence_symmetric_k_13_fisher_th_0_0001.csv(4)",
    "name" : "co_occurrence_symmetric_k_13_fisher_th_0_0001.csv(4)",
    "SUID" : 134421,
    "selected" : true
  },
  "elements" : {
    "nodes" : [ {
      "data" : {
        "id" : "80357",
        "shared_name" : "CRISPR-associated endoribonuclease Cas6",
        "MCODE_Node_Status_2_" : "Unclustered",
        "MCODE_Node_Status_1_" : "Unclustered",
        "MCODE_Score_2_" : 0.0,
        "name" : "CRISPR-associated endoribonuclease Cas6",
        "MCODE_Score_1_" : 2.7,
        "SUID" : 80357,
        "selected" : false
      },
      "position" : {
        "x" : -1844.3596094692712,
        "y" : -40.479037212899726
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82150",
        "shared_name" : "Bacterial Ig-like domain (group 2)",
        "MCODE_Node_Status_2_" : "Clustered",
        "MCODE_Node_Status_1_" : "Seed",
        "MCODE_Score_2_" : 2.7777777777777777,
        "name" : "Bacterial Ig-like domain (group 2)",
        "MCODE_Score_1_" : 6.611111111111111,
        "SUID" : 82150,
        "MCODE_Clusters_2_" : [ "Cluster 5" ],
        "selected" : false,
        "MCODE_Clusters_1_" : [ "Cluster 7" ]
      },
      "position" : {
        "x" : -150.37855291999387,
        "y" : -1468.48141924074
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80614",
        "shared_name" : "YadA head domain repeat (2 copies)",
        "MCODE_Node_Status_2_" : "Clustered",
        "MCODE_Node_Status_1_" : "Clustered",
        "MCODE_Score_2_" : 3.4285714285714284,
        "name" : "YadA head domain repeat (2 copies)",
        "MCODE_Score_1_" : 3.6666666666666665,
        "SUID" : 80614,
        "MCODE_Clusters_2_" : [ "Cluster 4" ],
        "selected" : false,
        "MCODE_Clusters_1_" : [ "Cluster 6" ]
      },
      "position" : {
        "x" : 716.2780696455234,
        "y" : -2132.069199982614
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80355",
        "shared_name" : "CRISPR Cas6 N-terminal domain",
        "MCODE_Node_Status_2_" : "Unclustered",
        "MCODE_Node_Status_1_" : "Unclustered",
        "MCODE_Score_2_" : 0.0,
        "name" : "CRISPR Cas6 N-terminal domain",
        "MCODE_Score_1_" : 1.2,
        "SUID" : 80355,
        "selected" : false
      },
      "position" : {
        "x" : -1971.9315701337223,
        "y" : 144.34085518741574
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80483",
        "shared_name" : "Reverse transcriptase (RNA-dependent DNA polymerase)",
        "MCODE_Node_Status_2_" : "Clustered",
        "MCODE_Node_Status_1_" : "Clustered",
        "MCODE_Score_2_" : 5.0,
        "name" : "Reverse transcriptase (RNA-dependent DNA polymerase)",
        "MCODE_Score_1_" : 6.0,
        "SUID" : 80483,
        "MCODE_Clusters_2_" : [ "Cluster 2" ],
        "selected" : false,
        "MCODE_Clusters_1_" : [ "Cluster 3" ]
      },
      "position" : {
        "x" : -1844.3596094692712,
        "y" : -424.5027771628054
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80740",
        "shared_name" : "Integrase zinc binding domain",
        "MCODE_Node_Status_2_" : "Unclustered",
        "MCODE_Node_Status_1_" : "Clustered",
        "MCODE_Score_2_" : 3.0,
        "name" : "Integrase zinc binding domain",
        "MCODE_Score_1_" : 5.0,
        "SUID" : 80740,
        "selected" : false,
        "MCODE_Clusters_1_" : [ "Cluster 21" ]
      },
      "position" : {
        "x" : -2152.4359843564184,
        "y" : -425.25744564542924
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80481",
        "shared_name" : "CRISPR associated protein Cas1",
        "MCODE_Node_Status_2_" : "Clustered",
        "MCODE_Node_Status_1_" : "Clustered",
        "MCODE_Score_2_" : 5.0,
        "name" : "CRISPR associated protein Cas1",
        "MCODE_Score_1_" : 6.0,
        "SUID" : 80481,
        "MCODE_Clusters_2_" : [ "Cluster 2" ],
        "selected" : false,
        "MCODE_Clusters_1_" : [ "Cluster 3" ]
      },
      "position" : {
        "x" : -1918.4107488720936,
        "y" : -124.06549451233113
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80866",
        "shared_name" : "EAL domain",
        "MCODE_Node_Status_2_" : "Seed",
        "MCODE_Node_Status_1_" : "Clustered",
        "MCODE_Score_2_" : 5.0,
        "name" : "EAL domain",
        "MCODE_Score_1_" : 6.0,
        "SUID" : 80866,
        "MCODE_Clusters_2_" : [ "Cluster 1" ],
        "selected" : false,
        "MCODE_Clusters_1_" : [ "Cluster 1" ]
      },
      "position" : {
        "x" : -1707.3288996483725,
        "y" : -1289.209880277046
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80738",
        "shared_name" : "Integrase core domain",
        "MCODE_Node_Status_2_" : "Unclustered",
        "MCODE_Node_Status_1_" : "Clustered",
        "MCODE_Score_2_" : 1.7142857142857142,
        "name" : "Integrase core domain",
        "MCODE_Score_1_" : 5.0,
        "SUID" : 80738,
        "selected" : false,
        "MCODE_Clusters_1_" : [ "Cluster 21" ]
      },
      "position" : {
        "x" : -2287.9897190531024,
        "y" : -471.89632438174885
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82527",
        "shared_name" : "Dockerin type I domain",
        "MCODE_Node_Status_2_" : "Clustered",
        "MCODE_Node_Status_1_" : "Unclustered",
        "MCODE_Score_2_" : 3.466666666666667,
        "name" : "Dockerin type I domain",
        "MCODE_Score_1_" : 5.2,
        "SUID" : 82527,
        "MCODE_Clusters_2_" : [ "Cluster 5" ],
        "selected" : false
      },
      "position" : {
        "x" : 605.7867295007381,
        "y" : -1516.0553063730017
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81504",
        "shared_name" : "WYL domain",
        "name" : "WYL domain",
        "SUID" : 81504,
        "selected" : false
      },
      "position" : {
        "x" : -2249.7104149700563,
        "y" : -1307.1068681857469
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80861",
        "shared_name" : "UvrD/REP helicase N-terminal domain",
        "MCODE_Node_Status_2_" : "Seed",
        "MCODE_Node_Status_1_" : "Clustered",
        "MCODE_Score_2_" : 5.0,
        "name" : "UvrD/REP helicase N-terminal domain",
        "MCODE_Score_1_" : 6.0,
        "SUID" : 80861,
        "MCODE_Clusters_2_" : [ "Cluster 2" ],
        "selected" : false,
        "MCODE_Clusters_1_" : [ "Cluster 3" ]
      },
      "position" : {
        "x" : -1629.0898707878057,
        "y" : -450.6412557612472
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80731",
        "shared_name" : "Recombinase",
        "MCODE_Node_Status_2_" : "Unclustered",
        "MCODE_Node_Status_1_" : "Clustered",
        "MCODE_Score_2_" : 3.0,
        "name" : "Recombinase",
        "MCODE_Score_1_" : 3.238095238095238,
        "SUID" : 80731,
        "selected" : false,
        "MCODE_Clusters_1_" : [ "Cluster 23" ]
      },
      "position" : {
        "x" : -1057.1725219945586,
        "y" : -679.5675775775571
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80859",
        "shared_name" : "UvrD-like helicase C-terminal domain",
        "MCODE_Node_Status_2_" : "Clustered",
        "MCODE_Node_Status_1_" : "Clustered",
        "MCODE_Score_2_" : 5.0,
        "name" : "UvrD-like helicase C-terminal domain",
        "MCODE_Score_1_" : 6.0,
        "SUID" : 80859,
        "MCODE_Clusters_2_" : [ "Cluster 2" ],
        "selected" : false,
        "MCODE_Clusters_1_" : [ "Cluster 3" ]
      },
      "position" : {
        "x" : -1485.2911750393105,
        "y" : -176.65573213948858
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80985",
        "shared_name" : "Calx-beta domain",
        "MCODE_Node_Status_2_" : "Seed",
        "MCODE_Node_Status_1_" : "Clustered",
        "MCODE_Score_2_" : 4.523809523809524,
        "name" : "Calx-beta domain",
        "MCODE_Score_1_" : 5.785714285714286,
        "SUID" : 80985,
        "MCODE_Clusters_2_" : [ "Cluster 7" ],
        "selected" : false,
        "MCODE_Clusters_1_" : [ "Cluster 7" ]
      },
      "position" : {
        "x" : 528.7969649978542,
        "y" : -906.6185668759754
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80474",
        "shared_name" : "His Kinase A (phospho-acceptor) domain",
        "MCODE_Node_Status_2_" : "Clustered",
        "MCODE_Node_Status_1_" : "Clustered",
        "MCODE_Score_2_" : 4.464285714285714,
        "name" : "His Kinase A (phospho-acceptor) domain",
        "MCODE_Score_1_" : 4.933333333333334,
        "SUID" : 80474,
        "MCODE_Clusters_2_" : [ "Cluster 1" ],
        "selected" : false,
        "MCODE_Clusters_1_" : [ "Cluster 1" ]
      },
      "position" : {
        "x" : -994.2201548652336,
        "y" : -1772.7096062130518
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80593",
        "shared_name" : "Response regulator receiver domain",
        "MCODE_Node_Status_2_" : "Clustered",
        "MCODE_Node_Status_1_" : "Clustered",
        "MCODE_Score_2_" : 4.464285714285714,
        "name" : "Response regulator receiver domain",
        "MCODE_Score_1_" : 6.0,
        "SUID" : 80593,
        "MCODE_Clusters_2_" : [ "Cluster 1" ],
        "selected" : false,
        "MCODE_Clusters_1_" : [ "Cluster 1" ]
      },
      "position" : {
        "x" : -1215.041451839486,
        "y" : -1808.9114203007566
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80848",
        "shared_name" : "Secretion system C-terminal sorting domain",
        "MCODE_Node_Status_2_" : "Clustered",
        "MCODE_Node_Status_1_" : "Clustered",
        "MCODE_Score_2_" : 2.7777777777777777,
        "name" : "Secretion system C-terminal sorting domain",
        "MCODE_Score_1_" : 4.0,
        "SUID" : 80848,
        "MCODE_Clusters_2_" : [ "Cluster 5" ],
        "selected" : false,
        "MCODE_Clusters_1_" : [ "Cluster 27" ]
      },
      "position" : {
        "x" : 659.9686865877834,
        "y" : -1417.4986923071936
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80717",
        "shared_name" : "CRISPR-Cas9 PI domain",
        "MCODE_Node_Status_2_" : "Seed",
        "MCODE_Node_Status_1_" : "Seed",
        "MCODE_Score_2_" : 3.7333333333333334,
        "name" : "CRISPR-Cas9 PI domain",
        "MCODE_Score_1_" : 3.7333333333333334,
        "SUID" : 80717,
        "MCODE_Clusters_2_" : [ "Cluster 3" ],
        "selected" : false,
        "MCODE_Clusters_1_" : [ "Cluster 8" ]
      },
      "position" : {
        "x" : -602.6099065693311,
        "y" : -140.7050462071341
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80846",
        "shared_name" : "BspA type Leucine rich repeat region (6 copies)",
        "MCODE_Node_Status_2_" : "Clustered",
        "MCODE_Node_Status_1_" : "Clustered",
        "MCODE_Score_2_" : 3.1818181818181817,
        "name" : "BspA type Leucine rich repeat region (6 copies)",
        "MCODE_Score_1_" : 4.272058823529412,
        "SUID" : 80846,
        "MCODE_Clusters_2_" : [ "Cluster 5" ],
        "selected" : false,
        "MCODE_Clusters_1_" : [ "Cluster 29" ]
      },
      "position" : {
        "x" : 2.386801508103815,
        "y" : -873.4996466010793
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81865",
        "shared_name" : "N-acetylmuramoyl-L-alanine amidase",
        "MCODE_Node_Status_2_" : "Unclustered",
        "MCODE_Node_Status_1_" : "Clustered",
        "MCODE_Score_2_" : 0.0,
        "name" : "N-acetylmuramoyl-L-alanine amidase",
        "MCODE_Score_1_" : 1.2545454545454544,
        "SUID" : 81865,
        "selected" : false,
        "MCODE_Clusters_1_" : [ "Cluster 47" ]
      },
      "position" : {
        "x" : 326.87335131377233,
        "y" : -1693.05911851368
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81735",
        "shared_name" : "Subtilase family",
        "MCODE_Node_Status_2_" : "Unclustered",
        "MCODE_Node_Status_1_" : "Clustered",
        "MCODE_Score_2_" : 3.0,
        "name" : "Subtilase family",
        "MCODE_Score_1_" : 5.785714285714286,
        "SUID" : 81735,
        "selected" : false,
        "MCODE_Clusters_1_" : [ "Cluster 7" ]
      },
      "position" : {
        "x" : -84.27141761792907,
        "y" : -1559.4700850846434
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80328",
        "shared_name" : "Methyl-accepting chemotaxis protein (MCP) signalling domain",
        "MCODE_Node_Status_2_" : "Clustered",
        "MCODE_Node_Status_1_" : "Clustered",
        "MCODE_Score_2_" : 4.0,
        "name" : "Methyl-accepting chemotaxis protein (MCP) signalling domain",
        "MCODE_Score_1_" : 5.0,
        "SUID" : 80328,
        "MCODE_Clusters_2_" : [ "Cluster 1" ],
        "selected" : false,
        "MCODE_Clusters_1_" : [ "Cluster 1" ]
      },
      "position" : {
        "x" : -576.7174555558985,
        "y" : -1253.148713346686
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80581",
        "shared_name" : "Extended Signal Peptide of Type V secretion system",
        "MCODE_Node_Status_2_" : "Clustered",
        "MCODE_Node_Status_1_" : "Clustered",
        "MCODE_Score_2_" : 3.4285714285714284,
        "name" : "Extended Signal Peptide of Type V secretion system",
        "MCODE_Score_1_" : 3.142857142857143,
        "SUID" : 80581,
        "MCODE_Clusters_2_" : [ "Cluster 4" ],
        "selected" : false,
        "MCODE_Clusters_1_" : [ "Cluster 6" ]
      },
      "position" : {
        "x" : 530.4208344405494,
        "y" : -2116.4623318898803
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80326",
        "shared_name" : "HAMP domain",
        "MCODE_Node_Status_2_" : "Clustered",
        "MCODE_Node_Status_1_" : "Clustered",
        "MCODE_Score_2_" : 4.0,
        "name" : "HAMP domain",
        "MCODE_Score_1_" : 5.0,
        "SUID" : 80326,
        "MCODE_Clusters_2_" : [ "Cluster 1" ],
        "selected" : false,
        "MCODE_Clusters_1_" : [ "Cluster 1" ]
      },
      "position" : {
        "x" : -1169.5517627561076,
        "y" : -673.4745521884288
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81476",
        "shared_name" : "S-layer homology domain",
        "MCODE_Node_Status_2_" : "Unclustered",
        "MCODE_Node_Status_1_" : "Unclustered",
        "MCODE_Score_2_" : 2.0444444444444443,
        "name" : "S-layer homology domain",
        "MCODE_Score_1_" : 4.107142857142857,
        "SUID" : 81476,
        "selected" : false
      },
      "position" : {
        "x" : 433.8369431314011,
        "y" : -1658.3045407523152
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80834",
        "shared_name" : "Actin like proteins N terminal domain",
        "MCODE_Node_Status_2_" : "Unclustered",
        "MCODE_Node_Status_1_" : "Unclustered",
        "MCODE_Score_2_" : 0.0,
        "name" : "Actin like proteins N terminal domain",
        "MCODE_Score_1_" : 0.0,
        "SUID" : 80834,
        "selected" : false
      },
      "position" : {
        "x" : -1945.135212886716,
        "y" : -232.49090718785254
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80706",
        "shared_name" : "GAF domain",
        "MCODE_Node_Status_2_" : "Clustered",
        "MCODE_Node_Status_1_" : "Clustered",
        "MCODE_Score_2_" : 4.464285714285714,
        "name" : "GAF domain",
        "MCODE_Score_1_" : 4.933333333333334,
        "SUID" : 80706,
        "MCODE_Clusters_2_" : [ "Cluster 1" ],
        "selected" : false,
        "MCODE_Clusters_1_" : [ "Cluster 1" ]
      },
      "position" : {
        "x" : -1659.2251546291695,
        "y" : -1507.7473970922583
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80450",
        "shared_name" : "PAM-interacting domain of CRISPR-associated endonuclease Cas9",
        "MCODE_Node_Status_2_" : "Clustered",
        "MCODE_Node_Status_1_" : "Clustered",
        "MCODE_Score_2_" : 3.238095238095238,
        "name" : "PAM-interacting domain of CRISPR-associated endonuclease Cas9",
        "MCODE_Score_1_" : 3.238095238095238,
        "SUID" : 80450,
        "MCODE_Clusters_2_" : [ "Cluster 3" ],
        "selected" : false,
        "MCODE_Clusters_1_" : [ "Cluster 8" ]
      },
      "position" : {
        "x" : -506.06452404170426,
        "y" : -84.96454361579373
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80445",
        "shared_name" : "REC lobe of CRISPR-associated endonuclease Cas9",
        "MCODE_Node_Status_2_" : "Clustered",
        "MCODE_Node_Status_1_" : "Clustered",
        "MCODE_Score_2_" : 3.7333333333333334,
        "name" : "REC lobe of CRISPR-associated endonuclease Cas9",
        "MCODE_Score_1_" : 3.7333333333333334,
        "SUID" : 80445,
        "MCODE_Clusters_2_" : [ "Cluster 3" ],
        "selected" : false,
        "MCODE_Clusters_1_" : [ "Cluster 8" ]
      },
      "position" : {
        "x" : -506.0645240417047,
        "y" : -501.0173190364089
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81086",
        "shared_name" : "PE family",
        "MCODE_Node_Status_2_" : "Seed",
        "MCODE_Node_Status_1_" : "Seed",
        "MCODE_Score_2_" : 4.0,
        "name" : "PE family",
        "MCODE_Score_1_" : 3.7333333333333334,
        "SUID" : 81086,
        "MCODE_Clusters_2_" : [ "Cluster 4" ],
        "selected" : false,
        "MCODE_Clusters_1_" : [ "Cluster 6" ]
      },
      "position" : {
        "x" : 618.8441372957627,
        "y" : -2177.9181283244625
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81468",
        "shared_name" : "Divergent InlB B-repeat domain",
        "MCODE_Node_Status_2_" : "Clustered",
        "MCODE_Node_Status_1_" : "Clustered",
        "MCODE_Score_2_" : 2.7777777777777777,
        "name" : "Divergent InlB B-repeat domain",
        "MCODE_Score_1_" : 3.6666666666666665,
        "SUID" : 81468,
        "MCODE_Clusters_2_" : [ "Cluster 5" ],
        "selected" : false,
        "MCODE_Clusters_1_" : [ "Cluster 27" ]
      },
      "position" : {
        "x" : -150.37855291999387,
        "y" : -1036.1782260158852
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81721",
        "shared_name" : "Autotransporter beta-domain",
        "MCODE_Node_Status_2_" : "Unclustered",
        "MCODE_Node_Status_1_" : "Clustered",
        "MCODE_Score_2_" : 0.0,
        "name" : "Autotransporter beta-domain",
        "MCODE_Score_1_" : 3.4285714285714284,
        "SUID" : 81721,
        "selected" : false,
        "MCODE_Clusters_1_" : [ "Cluster 27" ]
      },
      "position" : {
        "x" : 687.9383846279134,
        "y" : -1308.5639107108505
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82745",
        "shared_name" : "Fibronectin type III domain",
        "MCODE_Node_Status_2_" : "Unclustered",
        "MCODE_Node_Status_1_" : "Clustered",
        "MCODE_Score_2_" : 2.7,
        "name" : "Fibronectin type III domain",
        "MCODE_Score_1_" : 3.75,
        "SUID" : 82745,
        "selected" : false,
        "MCODE_Clusters_1_" : [ "Cluster 27" ]
      },
      "position" : {
        "x" : -84.27141761792907,
        "y" : -945.1895601719818
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80954",
        "shared_name" : "Leucine rich repeat",
        "MCODE_Node_Status_2_" : "Clustered",
        "MCODE_Node_Status_1_" : "Clustered",
        "MCODE_Score_2_" : 3.7333333333333334,
        "name" : "Leucine rich repeat",
        "MCODE_Score_1_" : 5.9818181818181815,
        "SUID" : 80954,
        "MCODE_Clusters_2_" : [ "Cluster 7" ],
        "selected" : false,
        "MCODE_Clusters_1_" : [ "Cluster 7" ]
      },
      "position" : {
        "x" : -191.7808499620249,
        "y" : -1363.911153631713
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80826",
        "shared_name" : "Four helix bundle sensory module for signal transduction",
        "MCODE_Node_Status_2_" : "Unclustered",
        "MCODE_Node_Status_1_" : "Unclustered",
        "MCODE_Score_2_" : 0.0,
        "name" : "Four helix bundle sensory module for signal transduction",
        "MCODE_Score_1_" : 4.0,
        "SUID" : 80826,
        "selected" : false
      },
      "position" : {
        "x" : -1430.6541803053155,
        "y" : -829.3729196317261
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80314",
        "shared_name" : "ParB/Sulfiredoxin domain",
        "MCODE_Node_Status_2_" : "Clustered",
        "MCODE_Node_Status_1_" : "Clustered",
        "MCODE_Score_2_" : 4.0,
        "name" : "ParB/Sulfiredoxin domain",
        "MCODE_Score_1_" : 5.0,
        "SUID" : 80314,
        "MCODE_Clusters_2_" : [ "Cluster 1" ],
        "selected" : false,
        "MCODE_Clusters_1_" : [ "Cluster 1" ]
      },
      "position" : {
        "x" : -693.6438907592451,
        "y" : -1123.0246583888795
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80952",
        "shared_name" : "Leucine Rich Repeat",
        "MCODE_Node_Status_2_" : "Clustered",
        "MCODE_Node_Status_1_" : "Clustered",
        "MCODE_Score_2_" : 4.523809523809524,
        "name" : "Leucine Rich Repeat",
        "MCODE_Score_1_" : 5.9818181818181815,
        "SUID" : 80952,
        "MCODE_Clusters_2_" : [ "Cluster 7" ],
        "selected" : false,
        "MCODE_Clusters_1_" : [ "Cluster 7" ]
      },
      "position" : {
        "x" : -191.78084996202466,
        "y" : -1140.748491624912
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80312",
        "shared_name" : "HTH domain found in ParB protein",
        "MCODE_Node_Status_2_" : "Clustered",
        "MCODE_Node_Status_1_" : "Clustered",
        "MCODE_Score_2_" : 4.0,
        "name" : "HTH domain found in ParB protein",
        "MCODE_Score_1_" : 5.0,
        "SUID" : 80312,
        "MCODE_Clusters_2_" : [ "Cluster 1" ],
        "selected" : false,
        "MCODE_Clusters_1_" : [ "Cluster 1" ]
      },
      "position" : {
        "x" : -579.5112898911239,
        "y" : -1477.9838460870258
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80566",
        "shared_name" : "Cas3 C-terminal domain",
        "name" : "Cas3 C-terminal domain",
        "SUID" : 80566,
        "selected" : false
      },
      "position" : {
        "x" : -2488.5280801776166,
        "y" : -1252.5982945330297
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82611",
        "shared_name" : "CHASE domain",
        "MCODE_Node_Status_2_" : "Clustered",
        "MCODE_Node_Status_1_" : "Seed",
        "MCODE_Score_2_" : 5.0,
        "name" : "CHASE domain",
        "MCODE_Score_1_" : 6.0,
        "SUID" : 82611,
        "MCODE_Clusters_2_" : [ "Cluster 1" ],
        "selected" : false,
        "MCODE_Clusters_1_" : [ "Cluster 1" ]
      },
      "position" : {
        "x" : -1695.1607207633965,
        "y" : -1401.0944374561218
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80688",
        "shared_name" : "CRISPR-Cas9 WED domain",
        "MCODE_Node_Status_2_" : "Clustered",
        "MCODE_Node_Status_1_" : "Clustered",
        "MCODE_Score_2_" : 3.7333333333333334,
        "name" : "CRISPR-Cas9 WED domain",
        "MCODE_Score_1_" : 3.7333333333333334,
        "SUID" : 80688,
        "MCODE_Clusters_2_" : [ "Cluster 3" ],
        "selected" : false,
        "MCODE_Clusters_1_" : [ "Cluster 8" ]
      },
      "position" : {
        "x" : -658.3504091606724,
        "y" : -348.7314339174424
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80558",
        "shared_name" : "PAS fold",
        "MCODE_Node_Status_2_" : "Clustered",
        "MCODE_Node_Status_1_" : "Clustered",
        "MCODE_Score_2_" : 4.464285714285714,
        "name" : "PAS fold",
        "MCODE_Score_1_" : 6.0,
        "SUID" : 80558,
        "MCODE_Clusters_2_" : [ "Cluster 1" ],
        "selected" : false,
        "MCODE_Clusters_1_" : [ "Cluster 1" ]
      },
      "position" : {
        "x" : -1523.8058564628714,
        "y" : -892.5313232022143
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81198",
        "shared_name" : "Leucine Rich repeats (2 copies)",
        "MCODE_Node_Status_2_" : "Unclustered",
        "MCODE_Node_Status_1_" : "Clustered",
        "MCODE_Score_2_" : 0.0,
        "name" : "Leucine Rich repeats (2 copies)",
        "MCODE_Score_1_" : 5.785714285714286,
        "SUID" : 81198,
        "selected" : false,
        "MCODE_Clusters_1_" : [ "Cluster 7" ]
      },
      "position" : {
        "x" : -205.8768501538737,
        "y" : -1252.3298226283123
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80302",
        "shared_name" : "HD domain",
        "name" : "HD domain",
        "SUID" : 80302,
        "selected" : false
      },
      "position" : {
        "x" : -2403.2950422853733,
        "y" : -1429.5865214111332
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80427",
        "shared_name" : "Putative transposase DNA-binding domain",
        "MCODE_Node_Status_2_" : "Unclustered",
        "MCODE_Node_Status_1_" : "Unclustered",
        "MCODE_Score_2_" : 0.0,
        "name" : "Putative transposase DNA-binding domain",
        "MCODE_Score_1_" : 2.857142857142857,
        "SUID" : 80427,
        "selected" : false
      },
      "position" : {
        "x" : -2450.401102463394,
        "y" : -658.2888033679963
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80300",
        "shared_name" : "Csm1 subunit domain B",
        "name" : "Csm1 subunit domain B",
        "SUID" : 80300,
        "selected" : false
      },
      "position" : {
        "x" : -2442.565719800415,
        "y" : -1601.6426015245725
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80556",
        "shared_name" : "PAS domain",
        "MCODE_Node_Status_2_" : "Clustered",
        "MCODE_Node_Status_1_" : "Clustered",
        "MCODE_Score_2_" : 4.464285714285714,
        "name" : "PAS domain",
        "MCODE_Score_1_" : 6.0,
        "SUID" : 80556,
        "MCODE_Clusters_2_" : [ "Cluster 1" ],
        "selected" : false,
        "MCODE_Clusters_1_" : [ "Cluster 1" ]
      },
      "position" : {
        "x" : -1523.8058564628714,
        "y" : -1685.8884373518763
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80551",
        "shared_name" : "Putative cell wall binding repeat",
        "MCODE_Node_Status_2_" : "Clustered",
        "MCODE_Node_Status_1_" : "Clustered",
        "MCODE_Score_2_" : 2.7,
        "name" : "Putative cell wall binding repeat",
        "MCODE_Score_1_" : 5.333333333333333,
        "SUID" : 80551,
        "MCODE_Clusters_2_" : [ "Cluster 10" ],
        "selected" : false,
        "MCODE_Clusters_1_" : [ "Cluster 7" ]
      },
      "position" : {
        "x" : 104.15104984378058,
        "y" : -1679.0466190267286
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80549",
        "shared_name" : "Choline-binding repeat",
        "MCODE_Node_Status_2_" : "Clustered",
        "MCODE_Node_Status_1_" : "Clustered",
        "MCODE_Score_2_" : 2.7,
        "name" : "Choline-binding repeat",
        "MCODE_Score_1_" : 3.2727272727272725,
        "SUID" : 80549,
        "MCODE_Clusters_2_" : [ "Cluster 10" ],
        "selected" : false,
        "MCODE_Clusters_1_" : [ "Cluster 27" ]
      },
      "position" : {
        "x" : 687.9383846279129,
        "y" : -1196.0957345457723
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80422",
        "shared_name" : "Probable transposase",
        "MCODE_Node_Status_2_" : "Unclustered",
        "MCODE_Node_Status_1_" : "Unclustered",
        "MCODE_Score_2_" : 0.0,
        "name" : "Probable transposase",
        "MCODE_Score_1_" : 2.857142857142857,
        "SUID" : 80422,
        "selected" : false
      },
      "position" : {
        "x" : -2307.3515497994117,
        "y" : -648.9707841238755
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81187",
        "shared_name" : "RRXRR protein",
        "MCODE_Node_Status_2_" : "Seed",
        "MCODE_Node_Status_1_" : "Seed",
        "MCODE_Score_2_" : 5.0,
        "name" : "RRXRR protein",
        "MCODE_Score_1_" : 5.0,
        "SUID" : 81187,
        "MCODE_Clusters_2_" : [ "Cluster 6" ],
        "selected" : false,
        "MCODE_Clusters_1_" : [ "Cluster 16" ]
      },
      "position" : {
        "x" : -242.29763374005643,
        "y" : -237.25042873476133
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80420",
        "shared_name" : "Helix-turn-helix domain",
        "MCODE_Node_Status_2_" : "Unclustered",
        "MCODE_Node_Status_1_" : "Clustered",
        "MCODE_Score_2_" : 3.0,
        "name" : "Helix-turn-helix domain",
        "MCODE_Score_1_" : 4.0,
        "SUID" : 80420,
        "selected" : false,
        "MCODE_Clusters_1_" : [ "Cluster 21" ]
      },
      "position" : {
        "x" : -2370.806684753043,
        "y" : -777.5143403529473
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80676",
        "shared_name" : "Centromere-binding protein HTH domain",
        "MCODE_Node_Status_2_" : "Unclustered",
        "MCODE_Node_Status_1_" : "Unclustered",
        "MCODE_Score_2_" : 0.0,
        "name" : "Centromere-binding protein HTH domain",
        "MCODE_Score_1_" : 2.4000000000000004,
        "SUID" : 80676,
        "selected" : false
      },
      "position" : {
        "x" : -809.0089207836763,
        "y" : -1647.1332736076592
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81565",
        "shared_name" : "CHU_C Type IX secretion signal domain",
        "MCODE_Node_Status_2_" : "Unclustered",
        "MCODE_Node_Status_1_" : "Clustered",
        "MCODE_Score_2_" : 0.0,
        "name" : "CHU_C Type IX secretion signal domain",
        "MCODE_Score_1_" : 3.555555555555556,
        "SUID" : 81565,
        "selected" : false,
        "MCODE_Clusters_1_" : [ "Cluster 27" ]
      },
      "position" : {
        "x" : 104.15104984378058,
        "y" : -825.6130262298971
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81182",
        "shared_name" : "CRISPR-associated protein (Cas_Cas2CT1978)",
        "name" : "CRISPR-associated protein (Cas_Cas2CT1978)",
        "SUID" : 81182,
        "selected" : false
      },
      "position" : {
        "x" : -2488.5280801776166,
        "y" : -1361.615441838464
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80796",
        "shared_name" : "RNase H-like domain found in reverse transcriptase",
        "MCODE_Node_Status_2_" : "Unclustered",
        "MCODE_Node_Status_1_" : "Clustered",
        "MCODE_Score_2_" : 0.0,
        "name" : "RNase H-like domain found in reverse transcriptase",
        "MCODE_Score_1_" : 5.0,
        "SUID" : 80796,
        "selected" : false,
        "MCODE_Clusters_1_" : [ "Cluster 21" ]
      },
      "position" : {
        "x" : -2260.603305494435,
        "y" : -331.18390718840476
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80412",
        "shared_name" : "Cas9 alpha-helical lobe domain",
        "MCODE_Node_Status_2_" : "Clustered",
        "MCODE_Node_Status_1_" : "Clustered",
        "MCODE_Score_2_" : 5.0,
        "name" : "Cas9 alpha-helical lobe domain",
        "MCODE_Score_1_" : 5.0,
        "SUID" : 80412,
        "MCODE_Clusters_2_" : [ "Cluster 6" ],
        "selected" : false,
        "MCODE_Clusters_1_" : [ "Cluster 16" ]
      },
      "position" : {
        "x" : -658.3504091606721,
        "y" : -237.25042873476087
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82073",
        "shared_name" : "Domain of unknown function (DUF4118)",
        "MCODE_Node_Status_2_" : "Clustered",
        "MCODE_Node_Status_1_" : "Clustered",
        "MCODE_Score_2_" : 5.0,
        "name" : "Domain of unknown function (DUF4118)",
        "MCODE_Score_1_" : 5.0,
        "SUID" : 82073,
        "MCODE_Clusters_2_" : [ "Cluster 1" ],
        "selected" : false,
        "MCODE_Clusters_1_" : [ "Cluster 1" ]
      },
      "position" : {
        "x" : -1326.103148752425,
        "y" : -1790.7037792851515
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80407",
        "shared_name" : "Helicase conserved C-terminal domain",
        "name" : "Helicase conserved C-terminal domain",
        "SUID" : 80407,
        "selected" : false
      },
      "position" : {
        "x" : -2403.2950422853733,
        "y" : -1184.6272149603606
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80405",
        "shared_name" : "DEAD/DEAH box helicase",
        "name" : "DEAD/DEAH box helicase",
        "SUID" : 80405,
        "selected" : false
      },
      "position" : {
        "x" : -2297.011182470869,
        "y" : -1405.3279239754752
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81172",
        "shared_name" : "Helicase C-terminal domain",
        "name" : "Helicase C-terminal domain",
        "SUID" : 81172,
        "selected" : false
      },
      "position" : {
        "x" : -2186.977189230851,
        "y" : -1543.3061872931025
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80788",
        "shared_name" : "Cas9 C-terminal domain",
        "MCODE_Node_Status_2_" : "Clustered",
        "MCODE_Node_Status_1_" : "Clustered",
        "MCODE_Score_2_" : 4.761904761904762,
        "name" : "Cas9 C-terminal domain",
        "MCODE_Score_1_" : 4.761904761904762,
        "SUID" : 80788,
        "MCODE_Clusters_2_" : [ "Cluster 6" ],
        "selected" : false,
        "MCODE_Clusters_1_" : [ "Cluster 16" ]
      },
      "position" : {
        "x" : -242.29763374005643,
        "y" : -348.7314339174424
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81428",
        "shared_name" : "Y_Y_Y domain",
        "MCODE_Node_Status_2_" : "Unclustered",
        "MCODE_Node_Status_1_" : "Clustered",
        "MCODE_Score_2_" : 0.0,
        "name" : "Y_Y_Y domain",
        "MCODE_Score_1_" : 5.0,
        "SUID" : 81428,
        "selected" : false,
        "MCODE_Clusters_1_" : [ "Cluster 22" ]
      },
      "position" : {
        "x" : 659.9686865877825,
        "y" : -1087.1609529494294
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80532",
        "shared_name" : "YadA-like membrane anchor domain",
        "MCODE_Node_Status_2_" : "Clustered",
        "MCODE_Node_Status_1_" : "Clustered",
        "MCODE_Score_2_" : 3.4285714285714284,
        "name" : "YadA-like membrane anchor domain",
        "MCODE_Score_1_" : 3.6666666666666665,
        "SUID" : 80532,
        "MCODE_Clusters_2_" : [ "Cluster 4" ],
        "selected" : false,
        "MCODE_Clusters_1_" : [ "Cluster 6" ]
      },
      "position" : {
        "x" : 636.8653962848571,
        "y" : -1963.3086787716004
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80914",
        "shared_name" : "Histidine kinase",
        "MCODE_Node_Status_2_" : "Unclustered",
        "MCODE_Node_Status_1_" : "Clustered",
        "MCODE_Score_2_" : 3.0,
        "name" : "Histidine kinase",
        "MCODE_Score_1_" : 4.0,
        "SUID" : 80914,
        "selected" : false,
        "MCODE_Clusters_1_" : [ "Cluster 23" ]
      },
      "position" : {
        "x" : -994.2201548652314,
        "y" : -805.7101543410395
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80530",
        "shared_name" : "Coiled stalk of trimeric autotransporter adhesin",
        "MCODE_Node_Status_2_" : "Clustered",
        "MCODE_Node_Status_1_" : "Clustered",
        "MCODE_Score_2_" : 3.4285714285714284,
        "name" : "Coiled stalk of trimeric autotransporter adhesin",
        "MCODE_Score_1_" : 3.6666666666666665,
        "SUID" : 80530,
        "MCODE_Clusters_2_" : [ "Cluster 4" ],
        "selected" : false,
        "MCODE_Clusters_1_" : [ "Cluster 6" ]
      },
      "position" : {
        "x" : 725.2886991400705,
        "y" : -2024.7644752061838
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80783",
        "shared_name" : "Topo homolgy domain in CRISPR-associated endonuclease Cas9",
        "MCODE_Node_Status_2_" : "Clustered",
        "MCODE_Node_Status_1_" : "Clustered",
        "MCODE_Score_2_" : 4.761904761904762,
        "name" : "Topo homolgy domain in CRISPR-associated endonuclease Cas9",
        "MCODE_Score_1_" : 4.761904761904762,
        "SUID" : 80783,
        "MCODE_Clusters_2_" : [ "Cluster 6" ],
        "selected" : false,
        "MCODE_Clusters_1_" : [ "Cluster 16" ]
      },
      "position" : {
        "x" : -394.5835188590236,
        "y" : -501.0173190364089
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80781",
        "shared_name" : "CRISPR-associated endonuclease Cas9 beta-hairpin domain",
        "MCODE_Node_Status_2_" : "Clustered",
        "MCODE_Node_Status_1_" : "Clustered",
        "MCODE_Score_2_" : 4.761904761904762,
        "name" : "CRISPR-associated endonuclease Cas9 beta-hairpin domain",
        "MCODE_Score_1_" : 4.761904761904762,
        "SUID" : 80781,
        "MCODE_Clusters_2_" : [ "Cluster 6" ],
        "selected" : false,
        "MCODE_Clusters_1_" : [ "Cluster 16" ]
      },
      "position" : {
        "x" : -298.0381363313966,
        "y" : -445.27681644506873
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "83341",
        "shared_name" : "Listeria-Bacteroides repeat domain (List_Bact_rpt)",
        "MCODE_Node_Status_2_" : "Seed",
        "MCODE_Node_Status_1_" : "Unclustered",
        "MCODE_Score_2_" : 3.466666666666667,
        "name" : "Listeria-Bacteroides repeat domain (List_Bact_rpt)",
        "MCODE_Score_1_" : 3.106060606060606,
        "SUID" : 83341,
        "MCODE_Clusters_2_" : [ "Cluster 5" ],
        "selected" : false
      },
      "position" : {
        "x" : 528.7969649978564,
        "y" : -1598.0410783806483
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82057",
        "shared_name" : "Bacterial Ig domain",
        "MCODE_Node_Status_2_" : "Unclustered",
        "MCODE_Node_Status_1_" : "Clustered",
        "MCODE_Score_2_" : 2.7,
        "name" : "Bacterial Ig domain",
        "MCODE_Score_1_" : 4.181818181818182,
        "SUID" : 82057,
        "selected" : false,
        "MCODE_Clusters_1_" : [ "Cluster 29" ]
      },
      "position" : {
        "x" : 214.6271054034446,
        "y" : -804.5385915310258
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81290",
        "shared_name" : "Recombinase zinc beta ribbon domain",
        "MCODE_Node_Status_2_" : "Unclustered",
        "MCODE_Node_Status_1_" : "Clustered",
        "MCODE_Score_2_" : 0.0,
        "name" : "Recombinase zinc beta ribbon domain",
        "MCODE_Score_1_" : 3.238095238095238,
        "SUID" : 81290,
        "selected" : false,
        "MCODE_Clusters_1_" : [ "Cluster 23" ]
      },
      "position" : {
        "x" : -894.7859132251924,
        "y" : -1719.992907701057
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80650",
        "shared_name" : "Tetratricopeptide repeat",
        "MCODE_Node_Status_2_" : "Unclustered",
        "MCODE_Node_Status_1_" : "Unclustered",
        "MCODE_Score_2_" : 1.6666666666666667,
        "name" : "Tetratricopeptide repeat",
        "MCODE_Score_1_" : 0.40522875816993464,
        "SUID" : 80650,
        "selected" : false
      },
      "position" : {
        "x" : -809.008920783677,
        "y" : -931.2864869464306
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80903",
        "shared_name" : "HTH-like domain",
        "MCODE_Node_Status_2_" : "Unclustered",
        "MCODE_Node_Status_1_" : "Unclustered",
        "MCODE_Score_2_" : 0.0,
        "name" : "HTH-like domain",
        "MCODE_Score_1_" : 0.0,
        "SUID" : 80903,
        "selected" : false
      },
      "position" : {
        "x" : -2455.3443516595376,
        "y" : -453.06362433775666
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81800",
        "shared_name" : "SprB repeat",
        "MCODE_Node_Status_2_" : "Unclustered",
        "MCODE_Node_Status_1_" : "Clustered",
        "MCODE_Score_2_" : 0.0,
        "name" : "SprB repeat",
        "MCODE_Score_1_" : 3.4285714285714284,
        "SUID" : 81800,
        "selected" : false,
        "MCODE_Clusters_1_" : [ "Cluster 27" ]
      },
      "position" : {
        "x" : 326.8733513137719,
        "y" : -811.6005267429455
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80520",
        "shared_name" : "Cache domain",
        "MCODE_Node_Status_2_" : "Clustered",
        "MCODE_Node_Status_1_" : "Clustered",
        "MCODE_Score_2_" : 4.0,
        "name" : "Cache domain",
        "MCODE_Score_1_" : 5.0,
        "SUID" : 80520,
        "MCODE_Clusters_2_" : [ "Cluster 1" ],
        "selected" : false,
        "MCODE_Clusters_1_" : [ "Cluster 1" ]
      },
      "position" : {
        "x" : -561.2619991883403,
        "y" : -1378.7707038643355
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80648",
        "shared_name" : "TPR repeat",
        "MCODE_Node_Status_2_" : "Unclustered",
        "MCODE_Node_Status_1_" : "Unclustered",
        "MCODE_Score_2_" : 0.0,
        "name" : "TPR repeat",
        "MCODE_Score_1_" : 0.6909090909090909,
        "SUID" : 80648,
        "selected" : false
      },
      "position" : {
        "x" : -894.7859132251899,
        "y" : -858.4268528530351
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80771",
        "shared_name" : "KorB domain",
        "MCODE_Node_Status_2_" : "Unclustered",
        "MCODE_Node_Status_1_" : "Clustered",
        "MCODE_Score_2_" : 0.0,
        "name" : "KorB domain",
        "MCODE_Score_1_" : 5.0,
        "SUID" : 80771,
        "selected" : false,
        "MCODE_Clusters_1_" : [ "Cluster 1" ]
      },
      "position" : {
        "x" : -740.9000143729777,
        "y" : -1557.537539445404
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81028",
        "shared_name" : "PGRS repeats",
        "MCODE_Node_Status_2_" : "Clustered",
        "MCODE_Node_Status_1_" : "Clustered",
        "MCODE_Score_2_" : 4.0,
        "name" : "PGRS repeats",
        "MCODE_Score_1_" : 3.7333333333333334,
        "SUID" : 81028,
        "MCODE_Clusters_2_" : [ "Cluster 4" ],
        "selected" : false,
        "MCODE_Clusters_1_" : [ "Cluster 6" ]
      },
      "position" : {
        "x" : 539.4314639350965,
        "y" : -2009.1576071134489
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80386",
        "shared_name" : "RuvC endonuclease subdomain 3",
        "MCODE_Node_Status_2_" : "Clustered",
        "MCODE_Node_Status_1_" : "Clustered",
        "MCODE_Score_2_" : 3.0303030303030303,
        "name" : "RuvC endonuclease subdomain 3",
        "MCODE_Score_1_" : 3.0303030303030303,
        "SUID" : 80386,
        "MCODE_Clusters_2_" : [ "Cluster 3" ],
        "selected" : false,
        "MCODE_Clusters_1_" : [ "Cluster 8" ]
      },
      "position" : {
        "x" : -602.6099065693315,
        "y" : -445.27681644506873
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80384",
        "shared_name" : "HNH endonuclease",
        "MCODE_Node_Status_2_" : "Clustered",
        "MCODE_Node_Status_1_" : "Clustered",
        "MCODE_Score_2_" : 3.0303030303030303,
        "name" : "HNH endonuclease",
        "MCODE_Score_1_" : 3.0303030303030303,
        "SUID" : 80384,
        "MCODE_Clusters_2_" : [ "Cluster 3" ],
        "selected" : false,
        "MCODE_Clusters_1_" : [ "Cluster 8" ]
      },
      "position" : {
        "x" : -394.5835188590232,
        "y" : -84.96454361579373
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80637",
        "shared_name" : "Domain of unknown function DUF83",
        "MCODE_Node_Status_2_" : "Unclustered",
        "MCODE_Node_Status_1_" : "Unclustered",
        "MCODE_Score_2_" : 0.0,
        "name" : "Domain of unknown function DUF83",
        "MCODE_Score_1_" : 1.6666666666666667,
        "SUID" : 80637,
        "selected" : false
      },
      "position" : {
        "x" : -1918.4107488720936,
        "y" : -340.9163198633739
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81017",
        "shared_name" : "Leucine rich repeat N-terminal domain",
        "MCODE_Node_Status_2_" : "Clustered",
        "MCODE_Node_Status_1_" : "Clustered",
        "MCODE_Score_2_" : 3.7333333333333334,
        "name" : "Leucine rich repeat N-terminal domain",
        "MCODE_Score_1_" : 5.9818181818181815,
        "SUID" : 81017,
        "MCODE_Clusters_2_" : [ "Cluster 7" ],
        "selected" : false,
        "MCODE_Clusters_1_" : [ "Cluster 7" ]
      },
      "position" : {
        "x" : 433.83694313139836,
        "y" : -846.3551045043091
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80760",
        "shared_name" : "Domain of unknown function (DUF4143)",
        "MCODE_Node_Status_2_" : "Clustered",
        "MCODE_Node_Status_1_" : "Clustered",
        "MCODE_Score_2_" : 5.0,
        "name" : "Domain of unknown function (DUF4143)",
        "MCODE_Score_1_" : 6.0,
        "SUID" : 80760,
        "MCODE_Clusters_2_" : [ "Cluster 2" ],
        "selected" : false,
        "MCODE_Clusters_1_" : [ "Cluster 3" ]
      },
      "position" : {
        "x" : -1739.946018302465,
        "y" : -464.1016290448563
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80758",
        "shared_name" : "AAA domain",
        "MCODE_Node_Status_2_" : "Clustered",
        "MCODE_Node_Status_1_" : "Unclustered",
        "MCODE_Score_2_" : 5.0,
        "name" : "AAA domain",
        "MCODE_Score_1_" : 2.5894736842105264,
        "SUID" : 80758,
        "MCODE_Clusters_2_" : [ "Cluster 2" ],
        "selected" : false
      },
      "position" : {
        "x" : -1537.1869743595012,
        "y" : -387.2052666161696
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81521",
        "shared_name" : "Helix-turn-helix",
        "MCODE_Node_Status_2_" : "Unclustered",
        "MCODE_Node_Status_1_" : "Unclustered",
        "MCODE_Score_2_" : 0.0,
        "name" : "Helix-turn-helix",
        "MCODE_Score_1_" : 0.6666666666666666,
        "SUID" : 81521,
        "selected" : false
      },
      "position" : {
        "x" : -740.9000143729781,
        "y" : -1020.8822211086854
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80498",
        "shared_name" : "Bridge helix of CRISPR-associated endonuclease Cas9",
        "MCODE_Node_Status_2_" : "Clustered",
        "MCODE_Node_Status_1_" : "Clustered",
        "MCODE_Score_2_" : 3.7333333333333334,
        "name" : "Bridge helix of CRISPR-associated endonuclease Cas9",
        "MCODE_Score_1_" : 3.7333333333333334,
        "SUID" : 80498,
        "MCODE_Clusters_2_" : [ "Cluster 3" ],
        "selected" : false,
        "MCODE_Clusters_1_" : [ "Cluster 8" ]
      },
      "position" : {
        "x" : -298.0381363313966,
        "y" : -140.70504620713456
      },
      "selected" : false
    } ],
    "edges" : [ {
      "data" : {
        "id" : "82152",
        "source" : "82150",
        "target" : "80848",
        "shared_name" : "Bacterial Ig-like domain (group 2) (interacts with) Secretion system C-terminal sorting domain",
        "shared_interaction" : "interacts with",
        "name" : "Bacterial Ig-like domain (group 2) (interacts with) Secretion system C-terminal sorting domain",
        "interaction" : "interacts with",
        "SUID" : 82152,
        "selected" : false,
        "Count_normalized" : 3.85
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82266",
        "source" : "82150",
        "target" : "80846",
        "shared_name" : "Bacterial Ig-like domain (group 2) (interacts with) BspA type Leucine rich repeat region (6 copies)",
        "shared_interaction" : "interacts with",
        "name" : "Bacterial Ig-like domain (group 2) (interacts with) BspA type Leucine rich repeat region (6 copies)",
        "interaction" : "interacts with",
        "SUID" : 82266,
        "selected" : false,
        "Count_normalized" : 3.99
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80645",
        "source" : "80614",
        "target" : "80532",
        "shared_name" : "YadA head domain repeat (2 copies) (interacts with) YadA-like membrane anchor domain",
        "shared_interaction" : "interacts with",
        "name" : "YadA head domain repeat (2 copies) (interacts with) YadA-like membrane anchor domain",
        "interaction" : "interacts with",
        "SUID" : 80645,
        "selected" : false,
        "Count_normalized" : 4.58
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80359",
        "source" : "80355",
        "target" : "80357",
        "shared_name" : "CRISPR Cas6 N-terminal domain (interacts with) CRISPR-associated endoribonuclease Cas6",
        "shared_interaction" : "interacts with",
        "name" : "CRISPR Cas6 N-terminal domain (interacts with) CRISPR-associated endoribonuclease Cas6",
        "interaction" : "interacts with",
        "SUID" : 80359,
        "selected" : false,
        "Count_normalized" : 5.41
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "83028",
        "source" : "80483",
        "target" : "80859",
        "shared_name" : "Reverse transcriptase (RNA-dependent DNA polymerase) (interacts with) UvrD-like helicase C-terminal domain",
        "shared_interaction" : "interacts with",
        "name" : "Reverse transcriptase (RNA-dependent DNA polymerase) (interacts with) UvrD-like helicase C-terminal domain",
        "interaction" : "interacts with",
        "SUID" : 83028,
        "selected" : false,
        "Count_normalized" : 3.78
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80798",
        "source" : "80740",
        "target" : "80796",
        "shared_name" : "Integrase zinc binding domain (interacts with) RNase H-like domain found in reverse transcriptase",
        "shared_interaction" : "interacts with",
        "name" : "Integrase zinc binding domain (interacts with) RNase H-like domain found in reverse transcriptase",
        "interaction" : "interacts with",
        "SUID" : 80798,
        "selected" : false,
        "Count_normalized" : 4.14
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81494",
        "source" : "80740",
        "target" : "80483",
        "shared_name" : "Integrase zinc binding domain (interacts with) Reverse transcriptase (RNA-dependent DNA polymerase)",
        "shared_interaction" : "interacts with",
        "name" : "Integrase zinc binding domain (interacts with) Reverse transcriptase (RNA-dependent DNA polymerase)",
        "interaction" : "interacts with",
        "SUID" : 81494,
        "selected" : false,
        "Count_normalized" : 3.71
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "84185",
        "source" : "80481",
        "target" : "80859",
        "shared_name" : "CRISPR associated protein Cas1 (interacts with) UvrD-like helicase C-terminal domain",
        "shared_interaction" : "interacts with",
        "name" : "CRISPR associated protein Cas1 (interacts with) UvrD-like helicase C-terminal domain",
        "interaction" : "interacts with",
        "SUID" : 84185,
        "selected" : false,
        "Count_normalized" : 3.58
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81570",
        "source" : "80481",
        "target" : "80760",
        "shared_name" : "CRISPR associated protein Cas1 (interacts with) Domain of unknown function (DUF4143)",
        "shared_interaction" : "interacts with",
        "name" : "CRISPR associated protein Cas1 (interacts with) Domain of unknown function (DUF4143)",
        "interaction" : "interacts with",
        "SUID" : 81570,
        "selected" : false,
        "Count_normalized" : 3.76
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80485",
        "source" : "80481",
        "target" : "80483",
        "shared_name" : "CRISPR associated protein Cas1 (interacts with) Reverse transcriptase (RNA-dependent DNA polymerase)",
        "shared_interaction" : "interacts with",
        "name" : "CRISPR associated protein Cas1 (interacts with) Reverse transcriptase (RNA-dependent DNA polymerase)",
        "interaction" : "interacts with",
        "SUID" : 80485,
        "selected" : false,
        "Count_normalized" : 5.69
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80639",
        "source" : "80481",
        "target" : "80637",
        "shared_name" : "CRISPR associated protein Cas1 (interacts with) Domain of unknown function DUF83",
        "shared_interaction" : "interacts with",
        "name" : "CRISPR associated protein Cas1 (interacts with) Domain of unknown function DUF83",
        "interaction" : "interacts with",
        "SUID" : 80639,
        "selected" : false,
        "Count_normalized" : 4.67
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80868",
        "source" : "80866",
        "target" : "80558",
        "shared_name" : "EAL domain (interacts with) PAS fold",
        "shared_interaction" : "interacts with",
        "name" : "EAL domain (interacts with) PAS fold",
        "interaction" : "interacts with",
        "SUID" : 80868,
        "selected" : false,
        "Count_normalized" : 5.42
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81883",
        "source" : "80866",
        "target" : "80474",
        "shared_name" : "EAL domain (interacts with) His Kinase A (phospho-acceptor) domain",
        "shared_interaction" : "interacts with",
        "name" : "EAL domain (interacts with) His Kinase A (phospho-acceptor) domain",
        "interaction" : "interacts with",
        "SUID" : 81883,
        "selected" : false,
        "Count_normalized" : 4.86
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80975",
        "source" : "80866",
        "target" : "80556",
        "shared_name" : "EAL domain (interacts with) PAS domain",
        "shared_interaction" : "interacts with",
        "name" : "EAL domain (interacts with) PAS domain",
        "interaction" : "interacts with",
        "SUID" : 80975,
        "selected" : false,
        "Count_normalized" : 5.08
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81966",
        "source" : "80866",
        "target" : "80706",
        "shared_name" : "EAL domain (interacts with) GAF domain",
        "shared_interaction" : "interacts with",
        "name" : "EAL domain (interacts with) GAF domain",
        "interaction" : "interacts with",
        "SUID" : 81966,
        "selected" : false,
        "Count_normalized" : 4.53
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80908",
        "source" : "80866",
        "target" : "80593",
        "shared_name" : "EAL domain (interacts with) Response regulator receiver domain",
        "shared_interaction" : "interacts with",
        "name" : "EAL domain (interacts with) Response regulator receiver domain",
        "interaction" : "interacts with",
        "SUID" : 80908,
        "selected" : false,
        "Count_normalized" : 5.32
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80853",
        "source" : "80738",
        "target" : "80796",
        "shared_name" : "Integrase core domain (interacts with) RNase H-like domain found in reverse transcriptase",
        "shared_interaction" : "interacts with",
        "name" : "Integrase core domain (interacts with) RNase H-like domain found in reverse transcriptase",
        "interaction" : "interacts with",
        "SUID" : 80853,
        "selected" : false,
        "Count_normalized" : 4.16
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81622",
        "source" : "80738",
        "target" : "80483",
        "shared_name" : "Integrase core domain (interacts with) Reverse transcriptase (RNA-dependent DNA polymerase)",
        "shared_interaction" : "interacts with",
        "name" : "Integrase core domain (interacts with) Reverse transcriptase (RNA-dependent DNA polymerase)",
        "interaction" : "interacts with",
        "SUID" : 81622,
        "selected" : false,
        "Count_normalized" : 3.89
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82062",
        "source" : "80738",
        "target" : "80427",
        "shared_name" : "Integrase core domain (interacts with) Putative transposase DNA-binding domain",
        "shared_interaction" : "interacts with",
        "name" : "Integrase core domain (interacts with) Putative transposase DNA-binding domain",
        "interaction" : "interacts with",
        "SUID" : 82062,
        "selected" : false,
        "Count_normalized" : 3.71
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82572",
        "source" : "80738",
        "target" : "80422",
        "shared_name" : "Integrase core domain (interacts with) Probable transposase",
        "shared_interaction" : "interacts with",
        "name" : "Integrase core domain (interacts with) Probable transposase",
        "interaction" : "interacts with",
        "SUID" : 82572,
        "selected" : false,
        "Count_normalized" : 3.58
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80742",
        "source" : "80738",
        "target" : "80740",
        "shared_name" : "Integrase core domain (interacts with) Integrase zinc binding domain",
        "shared_interaction" : "interacts with",
        "name" : "Integrase core domain (interacts with) Integrase zinc binding domain",
        "interaction" : "interacts with",
        "SUID" : 80742,
        "selected" : false,
        "Count_normalized" : 4.34
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80863",
        "source" : "80859",
        "target" : "80861",
        "shared_name" : "UvrD-like helicase C-terminal domain (interacts with) UvrD/REP helicase N-terminal domain",
        "shared_interaction" : "interacts with",
        "name" : "UvrD-like helicase C-terminal domain (interacts with) UvrD/REP helicase N-terminal domain",
        "interaction" : "interacts with",
        "SUID" : 80863,
        "selected" : false,
        "Count_normalized" : 4.44
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80987",
        "source" : "80985",
        "target" : "80952",
        "shared_name" : "Calx-beta domain (interacts with) Leucine Rich Repeat",
        "shared_interaction" : "interacts with",
        "name" : "Calx-beta domain (interacts with) Leucine Rich Repeat",
        "interaction" : "interacts with",
        "SUID" : 80987,
        "selected" : false,
        "Count_normalized" : 3.93
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80831",
        "source" : "80474",
        "target" : "80593",
        "shared_name" : "His Kinase A (phospho-acceptor) domain (interacts with) Response regulator receiver domain",
        "shared_interaction" : "interacts with",
        "name" : "His Kinase A (phospho-acceptor) domain (interacts with) Response regulator receiver domain",
        "interaction" : "interacts with",
        "SUID" : 80831,
        "selected" : false,
        "Count_normalized" : 5.92
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81848",
        "source" : "80474",
        "target" : "81290",
        "shared_name" : "His Kinase A (phospho-acceptor) domain (interacts with) Recombinase zinc beta ribbon domain",
        "shared_interaction" : "interacts with",
        "name" : "His Kinase A (phospho-acceptor) domain (interacts with) Recombinase zinc beta ribbon domain",
        "interaction" : "interacts with",
        "SUID" : 81848,
        "selected" : false,
        "Count_normalized" : 4.01
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81075",
        "source" : "80474",
        "target" : "80731",
        "shared_name" : "His Kinase A (phospho-acceptor) domain (interacts with) Recombinase",
        "shared_interaction" : "interacts with",
        "name" : "His Kinase A (phospho-acceptor) domain (interacts with) Recombinase",
        "interaction" : "interacts with",
        "SUID" : 81075,
        "selected" : false,
        "Count_normalized" : 4.69
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "95130",
        "source" : "80474",
        "target" : "80650",
        "shared_name" : "His Kinase A (phospho-acceptor) domain (interacts with) Tetratricopeptide repeat",
        "shared_interaction" : "interacts with",
        "name" : "His Kinase A (phospho-acceptor) domain (interacts with) Tetratricopeptide repeat",
        "interaction" : "interacts with",
        "SUID" : 95130,
        "selected" : false,
        "Count_normalized" : 4.23
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81295",
        "source" : "80474",
        "target" : "80914",
        "shared_name" : "His Kinase A (phospho-acceptor) domain (interacts with) Histidine kinase",
        "shared_interaction" : "interacts with",
        "name" : "His Kinase A (phospho-acceptor) domain (interacts with) Histidine kinase",
        "interaction" : "interacts with",
        "SUID" : 81295,
        "selected" : false,
        "Count_normalized" : 4.69
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80722",
        "source" : "80474",
        "target" : "80558",
        "shared_name" : "His Kinase A (phospho-acceptor) domain (interacts with) PAS fold",
        "shared_interaction" : "interacts with",
        "name" : "His Kinase A (phospho-acceptor) domain (interacts with) PAS fold",
        "interaction" : "interacts with",
        "SUID" : 80722,
        "selected" : false,
        "Count_normalized" : 6.09
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80693",
        "source" : "80474",
        "target" : "80556",
        "shared_name" : "His Kinase A (phospho-acceptor) domain (interacts with) PAS domain",
        "shared_interaction" : "interacts with",
        "name" : "His Kinase A (phospho-acceptor) domain (interacts with) PAS domain",
        "interaction" : "interacts with",
        "SUID" : 80693,
        "selected" : false,
        "Count_normalized" : 6.0
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80820",
        "source" : "80717",
        "target" : "80386",
        "shared_name" : "CRISPR-Cas9 PI domain (interacts with) RuvC endonuclease subdomain 3",
        "shared_interaction" : "interacts with",
        "name" : "CRISPR-Cas9 PI domain (interacts with) RuvC endonuclease subdomain 3",
        "interaction" : "interacts with",
        "SUID" : 80820,
        "selected" : false,
        "Count_normalized" : 5.83
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "85883",
        "source" : "80717",
        "target" : "80412",
        "shared_name" : "CRISPR-Cas9 PI domain (interacts with) Cas9 alpha-helical lobe domain",
        "shared_interaction" : "interacts with",
        "name" : "CRISPR-Cas9 PI domain (interacts with) Cas9 alpha-helical lobe domain",
        "interaction" : "interacts with",
        "SUID" : 85883,
        "selected" : false,
        "Count_normalized" : 4.14
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80719",
        "source" : "80717",
        "target" : "80384",
        "shared_name" : "CRISPR-Cas9 PI domain (interacts with) HNH endonuclease",
        "shared_interaction" : "interacts with",
        "name" : "CRISPR-Cas9 PI domain (interacts with) HNH endonuclease",
        "interaction" : "interacts with",
        "SUID" : 80719,
        "selected" : false,
        "Count_normalized" : 6.08
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "83737",
        "source" : "80717",
        "target" : "80450",
        "shared_name" : "CRISPR-Cas9 PI domain (interacts with) PAM-interacting domain of CRISPR-associated endonuclease Cas9",
        "shared_interaction" : "interacts with",
        "name" : "CRISPR-Cas9 PI domain (interacts with) PAM-interacting domain of CRISPR-associated endonuclease Cas9",
        "interaction" : "interacts with",
        "SUID" : 83737,
        "selected" : false,
        "Count_normalized" : 4.16
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80850",
        "source" : "80846",
        "target" : "80848",
        "shared_name" : "BspA type Leucine rich repeat region (6 copies) (interacts with) Secretion system C-terminal sorting domain",
        "shared_interaction" : "interacts with",
        "name" : "BspA type Leucine rich repeat region (6 copies) (interacts with) Secretion system C-terminal sorting domain",
        "interaction" : "interacts with",
        "SUID" : 80850,
        "selected" : false,
        "Count_normalized" : 4.99
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82869",
        "source" : "80846",
        "target" : "82527",
        "shared_name" : "BspA type Leucine rich repeat region (6 copies) (interacts with) Dockerin type I domain",
        "shared_interaction" : "interacts with",
        "name" : "BspA type Leucine rich repeat region (6 copies) (interacts with) Dockerin type I domain",
        "interaction" : "interacts with",
        "SUID" : 82869,
        "selected" : false,
        "Count_normalized" : 3.66
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81065",
        "source" : "80846",
        "target" : "80952",
        "shared_name" : "BspA type Leucine rich repeat region (6 copies) (interacts with) Leucine Rich Repeat",
        "shared_interaction" : "interacts with",
        "name" : "BspA type Leucine rich repeat region (6 copies) (interacts with) Leucine Rich Repeat",
        "interaction" : "interacts with",
        "SUID" : 81065,
        "selected" : false,
        "Count_normalized" : 4.38
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81567",
        "source" : "80846",
        "target" : "81565",
        "shared_name" : "BspA type Leucine rich repeat region (6 copies) (interacts with) CHU_C Type IX secretion signal domain",
        "shared_interaction" : "interacts with",
        "name" : "BspA type Leucine rich repeat region (6 copies) (interacts with) CHU_C Type IX secretion signal domain",
        "interaction" : "interacts with",
        "SUID" : 81567,
        "selected" : false,
        "Count_normalized" : 3.93
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82324",
        "source" : "80846",
        "target" : "81476",
        "shared_name" : "BspA type Leucine rich repeat region (6 copies) (interacts with) S-layer homology domain",
        "shared_interaction" : "interacts with",
        "name" : "BspA type Leucine rich repeat region (6 copies) (interacts with) S-layer homology domain",
        "interaction" : "interacts with",
        "SUID" : 82324,
        "selected" : false,
        "Count_normalized" : 4.01
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81802",
        "source" : "80846",
        "target" : "81800",
        "shared_name" : "BspA type Leucine rich repeat region (6 copies) (interacts with) SprB repeat",
        "shared_interaction" : "interacts with",
        "name" : "BspA type Leucine rich repeat region (6 copies) (interacts with) SprB repeat",
        "interaction" : "interacts with",
        "SUID" : 81802,
        "selected" : false,
        "Count_normalized" : 3.69
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "84839",
        "source" : "80846",
        "target" : "83341",
        "shared_name" : "BspA type Leucine rich repeat region (6 copies) (interacts with) Listeria-Bacteroides repeat domain (List_Bact_rpt)",
        "shared_interaction" : "interacts with",
        "name" : "BspA type Leucine rich repeat region (6 copies) (interacts with) Listeria-Bacteroides repeat domain (List_Bact_rpt)",
        "interaction" : "interacts with",
        "SUID" : 84839,
        "selected" : false,
        "Count_normalized" : 3.76
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81254",
        "source" : "80846",
        "target" : "80954",
        "shared_name" : "BspA type Leucine rich repeat region (6 copies) (interacts with) Leucine rich repeat",
        "shared_interaction" : "interacts with",
        "name" : "BspA type Leucine rich repeat region (6 copies) (interacts with) Leucine rich repeat",
        "interaction" : "interacts with",
        "SUID" : 81254,
        "selected" : false,
        "Count_normalized" : 4.03
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81745",
        "source" : "80846",
        "target" : "81017",
        "shared_name" : "BspA type Leucine rich repeat region (6 copies) (interacts with) Leucine rich repeat N-terminal domain",
        "shared_interaction" : "interacts with",
        "name" : "BspA type Leucine rich repeat region (6 copies) (interacts with) Leucine rich repeat N-terminal domain",
        "interaction" : "interacts with",
        "SUID" : 81745,
        "selected" : false,
        "Count_normalized" : 3.76
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82747",
        "source" : "80846",
        "target" : "82745",
        "shared_name" : "BspA type Leucine rich repeat region (6 copies) (interacts with) Fibronectin type III domain",
        "shared_interaction" : "interacts with",
        "name" : "BspA type Leucine rich repeat region (6 copies) (interacts with) Fibronectin type III domain",
        "interaction" : "interacts with",
        "SUID" : 82747,
        "selected" : false,
        "Count_normalized" : 3.64
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81921",
        "source" : "80846",
        "target" : "81468",
        "shared_name" : "BspA type Leucine rich repeat region (6 copies) (interacts with) Divergent InlB B-repeat domain",
        "shared_interaction" : "interacts with",
        "name" : "BspA type Leucine rich repeat region (6 copies) (interacts with) Divergent InlB B-repeat domain",
        "interaction" : "interacts with",
        "SUID" : 81921,
        "selected" : false,
        "Count_normalized" : 4.13
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81149",
        "source" : "80846",
        "target" : "80985",
        "shared_name" : "BspA type Leucine rich repeat region (6 copies) (interacts with) Calx-beta domain",
        "shared_interaction" : "interacts with",
        "name" : "BspA type Leucine rich repeat region (6 copies) (interacts with) Calx-beta domain",
        "interaction" : "interacts with",
        "SUID" : 81149,
        "selected" : false,
        "Count_normalized" : 4.06
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81515",
        "source" : "80328",
        "target" : "80314",
        "shared_name" : "Methyl-accepting chemotaxis protein (MCP) signalling domain (interacts with) ParB/Sulfiredoxin domain",
        "shared_interaction" : "interacts with",
        "name" : "Methyl-accepting chemotaxis protein (MCP) signalling domain (interacts with) ParB/Sulfiredoxin domain",
        "interaction" : "interacts with",
        "SUID" : 81515,
        "selected" : false,
        "Count_normalized" : 4.34
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80608",
        "source" : "80581",
        "target" : "80532",
        "shared_name" : "Extended Signal Peptide of Type V secretion system (interacts with) YadA-like membrane anchor domain",
        "shared_interaction" : "interacts with",
        "name" : "Extended Signal Peptide of Type V secretion system (interacts with) YadA-like membrane anchor domain",
        "interaction" : "interacts with",
        "SUID" : 80608,
        "selected" : false,
        "Count_normalized" : 4.7
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80823",
        "source" : "80581",
        "target" : "80614",
        "shared_name" : "Extended Signal Peptide of Type V secretion system (interacts with) YadA head domain repeat (2 copies)",
        "shared_interaction" : "interacts with",
        "name" : "Extended Signal Peptide of Type V secretion system (interacts with) YadA head domain repeat (2 copies)",
        "interaction" : "interacts with",
        "SUID" : 80823,
        "selected" : false,
        "Count_normalized" : 4.17
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82659",
        "source" : "80326",
        "target" : "80914",
        "shared_name" : "HAMP domain (interacts with) Histidine kinase",
        "shared_interaction" : "interacts with",
        "name" : "HAMP domain (interacts with) Histidine kinase",
        "interaction" : "interacts with",
        "SUID" : 82659,
        "selected" : false,
        "Count_normalized" : 3.97
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "98270",
        "source" : "80326",
        "target" : "80558",
        "shared_name" : "HAMP domain (interacts with) PAS fold",
        "shared_interaction" : "interacts with",
        "name" : "HAMP domain (interacts with) PAS fold",
        "interaction" : "interacts with",
        "SUID" : 98270,
        "selected" : false,
        "Count_normalized" : 4.48
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "91594",
        "source" : "80326",
        "target" : "80312",
        "shared_name" : "HAMP domain (interacts with) HTH domain found in ParB protein",
        "shared_interaction" : "interacts with",
        "name" : "HAMP domain (interacts with) HTH domain found in ParB protein",
        "interaction" : "interacts with",
        "SUID" : 91594,
        "selected" : false,
        "Count_normalized" : 3.76
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80330",
        "source" : "80326",
        "target" : "80328",
        "shared_name" : "HAMP domain (interacts with) Methyl-accepting chemotaxis protein (MCP) signalling domain",
        "shared_interaction" : "interacts with",
        "name" : "HAMP domain (interacts with) Methyl-accepting chemotaxis protein (MCP) signalling domain",
        "interaction" : "interacts with",
        "SUID" : 80330,
        "selected" : false,
        "Count_normalized" : 6.05
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82310",
        "source" : "80326",
        "target" : "80474",
        "shared_name" : "HAMP domain (interacts with) His Kinase A (phospho-acceptor) domain",
        "shared_interaction" : "interacts with",
        "name" : "HAMP domain (interacts with) His Kinase A (phospho-acceptor) domain",
        "interaction" : "interacts with",
        "SUID" : 82310,
        "selected" : false,
        "Count_normalized" : 4.91
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82953",
        "source" : "80326",
        "target" : "80314",
        "shared_name" : "HAMP domain (interacts with) ParB/Sulfiredoxin domain",
        "shared_interaction" : "interacts with",
        "name" : "HAMP domain (interacts with) ParB/Sulfiredoxin domain",
        "interaction" : "interacts with",
        "SUID" : 82953,
        "selected" : false,
        "Count_normalized" : 4.3
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81689",
        "source" : "81476",
        "target" : "80532",
        "shared_name" : "S-layer homology domain (interacts with) YadA-like membrane anchor domain",
        "shared_interaction" : "interacts with",
        "name" : "S-layer homology domain (interacts with) YadA-like membrane anchor domain",
        "interaction" : "interacts with",
        "SUID" : 81689,
        "selected" : false,
        "Count_normalized" : 3.66
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81022",
        "source" : "80834",
        "target" : "80483",
        "shared_name" : "Actin like proteins N terminal domain (interacts with) Reverse transcriptase (RNA-dependent DNA polymerase)",
        "shared_interaction" : "interacts with",
        "name" : "Actin like proteins N terminal domain (interacts with) Reverse transcriptase (RNA-dependent DNA polymerase)",
        "interaction" : "interacts with",
        "SUID" : 81022,
        "selected" : false,
        "Count_normalized" : 3.83
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80972",
        "source" : "80834",
        "target" : "80481",
        "shared_name" : "Actin like proteins N terminal domain (interacts with) CRISPR associated protein Cas1",
        "shared_interaction" : "interacts with",
        "name" : "Actin like proteins N terminal domain (interacts with) CRISPR associated protein Cas1",
        "interaction" : "interacts with",
        "SUID" : 80972,
        "selected" : false,
        "Count_normalized" : 3.91
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80874",
        "source" : "80706",
        "target" : "80474",
        "shared_name" : "GAF domain (interacts with) His Kinase A (phospho-acceptor) domain",
        "shared_interaction" : "interacts with",
        "name" : "GAF domain (interacts with) His Kinase A (phospho-acceptor) domain",
        "interaction" : "interacts with",
        "SUID" : 80874,
        "selected" : false,
        "Count_normalized" : 5.63
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80871",
        "source" : "80706",
        "target" : "80593",
        "shared_name" : "GAF domain (interacts with) Response regulator receiver domain",
        "shared_interaction" : "interacts with",
        "name" : "GAF domain (interacts with) Response regulator receiver domain",
        "interaction" : "interacts with",
        "SUID" : 80871,
        "selected" : false,
        "Count_normalized" : 5.61
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80768",
        "source" : "80706",
        "target" : "80556",
        "shared_name" : "GAF domain (interacts with) PAS domain",
        "shared_interaction" : "interacts with",
        "name" : "GAF domain (interacts with) PAS domain",
        "interaction" : "interacts with",
        "SUID" : 80768,
        "selected" : false,
        "Count_normalized" : 5.63
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80708",
        "source" : "80706",
        "target" : "80558",
        "shared_name" : "GAF domain (interacts with) PAS fold",
        "shared_interaction" : "interacts with",
        "name" : "GAF domain (interacts with) PAS fold",
        "interaction" : "interacts with",
        "SUID" : 80708,
        "selected" : false,
        "Count_normalized" : 5.83
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80488",
        "source" : "80450",
        "target" : "80445",
        "shared_name" : "PAM-interacting domain of CRISPR-associated endonuclease Cas9 (interacts with) REC lobe of CRISPR-associated endonuclease Cas9",
        "shared_interaction" : "interacts with",
        "name" : "PAM-interacting domain of CRISPR-associated endonuclease Cas9 (interacts with) REC lobe of CRISPR-associated endonuclease Cas9",
        "interaction" : "interacts with",
        "SUID" : 80488,
        "selected" : false,
        "Count_normalized" : 6.38
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80929",
        "source" : "80450",
        "target" : "80386",
        "shared_name" : "PAM-interacting domain of CRISPR-associated endonuclease Cas9 (interacts with) RuvC endonuclease subdomain 3",
        "shared_interaction" : "interacts with",
        "name" : "PAM-interacting domain of CRISPR-associated endonuclease Cas9 (interacts with) RuvC endonuclease subdomain 3",
        "interaction" : "interacts with",
        "SUID" : 80929,
        "selected" : false,
        "Count_normalized" : 6.51
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80801",
        "source" : "80445",
        "target" : "80386",
        "shared_name" : "REC lobe of CRISPR-associated endonuclease Cas9 (interacts with) RuvC endonuclease subdomain 3",
        "shared_interaction" : "interacts with",
        "name" : "REC lobe of CRISPR-associated endonuclease Cas9 (interacts with) RuvC endonuclease subdomain 3",
        "interaction" : "interacts with",
        "SUID" : 80801,
        "selected" : false,
        "Count_normalized" : 6.81
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "89502",
        "source" : "80445",
        "target" : "81187",
        "shared_name" : "REC lobe of CRISPR-associated endonuclease Cas9 (interacts with) RRXRR protein",
        "shared_interaction" : "interacts with",
        "name" : "REC lobe of CRISPR-associated endonuclease Cas9 (interacts with) RRXRR protein",
        "interaction" : "interacts with",
        "SUID" : 89502,
        "selected" : false,
        "Count_normalized" : 3.64
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81470",
        "source" : "81468",
        "target" : "80848",
        "shared_name" : "Divergent InlB B-repeat domain (interacts with) Secretion system C-terminal sorting domain",
        "shared_interaction" : "interacts with",
        "name" : "Divergent InlB B-repeat domain (interacts with) Secretion system C-terminal sorting domain",
        "interaction" : "interacts with",
        "SUID" : 81470,
        "selected" : false,
        "Count_normalized" : 4.13
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81723",
        "source" : "81721",
        "target" : "80846",
        "shared_name" : "Autotransporter beta-domain (interacts with) BspA type Leucine rich repeat region (6 copies)",
        "shared_interaction" : "interacts with",
        "name" : "Autotransporter beta-domain (interacts with) BspA type Leucine rich repeat region (6 copies)",
        "interaction" : "interacts with",
        "SUID" : 81723,
        "selected" : false,
        "Count_normalized" : 3.69
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80828",
        "source" : "80826",
        "target" : "80328",
        "shared_name" : "Four helix bundle sensory module for signal transduction (interacts with) Methyl-accepting chemotaxis protein (MCP) signalling domain",
        "shared_interaction" : "interacts with",
        "name" : "Four helix bundle sensory module for signal transduction (interacts with) Methyl-accepting chemotaxis protein (MCP) signalling domain",
        "interaction" : "interacts with",
        "SUID" : 80828,
        "selected" : false,
        "Count_normalized" : 4.2
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80944",
        "source" : "80826",
        "target" : "80326",
        "shared_name" : "Four helix bundle sensory module for signal transduction (interacts with) HAMP domain",
        "shared_interaction" : "interacts with",
        "name" : "Four helix bundle sensory module for signal transduction (interacts with) HAMP domain",
        "interaction" : "interacts with",
        "SUID" : 80944,
        "selected" : false,
        "Count_normalized" : 4.08
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81019",
        "source" : "80952",
        "target" : "81017",
        "shared_name" : "Leucine Rich Repeat (interacts with) Leucine rich repeat N-terminal domain",
        "shared_interaction" : "interacts with",
        "name" : "Leucine Rich Repeat (interacts with) Leucine rich repeat N-terminal domain",
        "interaction" : "interacts with",
        "SUID" : 81019,
        "selected" : false,
        "Count_normalized" : 3.87
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80956",
        "source" : "80952",
        "target" : "80954",
        "shared_name" : "Leucine Rich Repeat (interacts with) Leucine rich repeat",
        "shared_interaction" : "interacts with",
        "name" : "Leucine Rich Repeat (interacts with) Leucine rich repeat",
        "interaction" : "interacts with",
        "SUID" : 80956,
        "selected" : false,
        "Count_normalized" : 4.08
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81200",
        "source" : "80952",
        "target" : "81198",
        "shared_name" : "Leucine Rich Repeat (interacts with) Leucine Rich repeats (2 copies)",
        "shared_interaction" : "interacts with",
        "name" : "Leucine Rich Repeat (interacts with) Leucine Rich repeats (2 copies)",
        "interaction" : "interacts with",
        "SUID" : 81200,
        "selected" : false,
        "Count_normalized" : 3.61
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81924",
        "source" : "80952",
        "target" : "80848",
        "shared_name" : "Leucine Rich Repeat (interacts with) Secretion system C-terminal sorting domain",
        "shared_interaction" : "interacts with",
        "name" : "Leucine Rich Repeat (interacts with) Secretion system C-terminal sorting domain",
        "interaction" : "interacts with",
        "SUID" : 81924,
        "selected" : false,
        "Count_normalized" : 3.83
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80316",
        "source" : "80312",
        "target" : "80314",
        "shared_name" : "HTH domain found in ParB protein (interacts with) ParB/Sulfiredoxin domain",
        "shared_interaction" : "interacts with",
        "name" : "HTH domain found in ParB protein (interacts with) ParB/Sulfiredoxin domain",
        "interaction" : "interacts with",
        "SUID" : 80316,
        "selected" : false,
        "Count_normalized" : 6.69
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81540",
        "source" : "80312",
        "target" : "81521",
        "shared_name" : "HTH domain found in ParB protein (interacts with) Helix-turn-helix",
        "shared_interaction" : "interacts with",
        "name" : "HTH domain found in ParB protein (interacts with) Helix-turn-helix",
        "interaction" : "interacts with",
        "SUID" : 81540,
        "selected" : false,
        "Count_normalized" : 3.95
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "83281",
        "source" : "80312",
        "target" : "80328",
        "shared_name" : "HTH domain found in ParB protein (interacts with) Methyl-accepting chemotaxis protein (MCP) signalling domain",
        "shared_interaction" : "interacts with",
        "name" : "HTH domain found in ParB protein (interacts with) Methyl-accepting chemotaxis protein (MCP) signalling domain",
        "interaction" : "interacts with",
        "SUID" : 83281,
        "selected" : false,
        "Count_normalized" : 3.83
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81214",
        "source" : "80312",
        "target" : "80771",
        "shared_name" : "HTH domain found in ParB protein (interacts with) KorB domain",
        "shared_interaction" : "interacts with",
        "name" : "HTH domain found in ParB protein (interacts with) KorB domain",
        "interaction" : "interacts with",
        "SUID" : 81214,
        "selected" : false,
        "Count_normalized" : 3.66
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80571",
        "source" : "80566",
        "target" : "80405",
        "shared_name" : "Cas3 C-terminal domain (interacts with) DEAD/DEAH box helicase",
        "shared_interaction" : "interacts with",
        "name" : "Cas3 C-terminal domain (interacts with) DEAD/DEAH box helicase",
        "interaction" : "interacts with",
        "SUID" : 80571,
        "selected" : false,
        "Count_normalized" : 5.99
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80568",
        "source" : "80566",
        "target" : "80407",
        "shared_name" : "Cas3 C-terminal domain (interacts with) Helicase conserved C-terminal domain",
        "shared_interaction" : "interacts with",
        "name" : "Cas3 C-terminal domain (interacts with) Helicase conserved C-terminal domain",
        "interaction" : "interacts with",
        "SUID" : 80568,
        "selected" : false,
        "Count_normalized" : 5.95
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82613",
        "source" : "82611",
        "target" : "80558",
        "shared_name" : "CHASE domain (interacts with) PAS fold",
        "shared_interaction" : "interacts with",
        "name" : "CHASE domain (interacts with) PAS fold",
        "interaction" : "interacts with",
        "SUID" : 82613,
        "selected" : false,
        "Count_normalized" : 3.83
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "84433",
        "source" : "80688",
        "target" : "80450",
        "shared_name" : "CRISPR-Cas9 WED domain (interacts with) PAM-interacting domain of CRISPR-associated endonuclease Cas9",
        "shared_interaction" : "interacts with",
        "name" : "CRISPR-Cas9 WED domain (interacts with) PAM-interacting domain of CRISPR-associated endonuclease Cas9",
        "interaction" : "interacts with",
        "SUID" : 84433,
        "selected" : false,
        "Count_normalized" : 4.16
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80755",
        "source" : "80688",
        "target" : "80386",
        "shared_name" : "CRISPR-Cas9 WED domain (interacts with) RuvC endonuclease subdomain 3",
        "shared_interaction" : "interacts with",
        "name" : "CRISPR-Cas9 WED domain (interacts with) RuvC endonuclease subdomain 3",
        "interaction" : "interacts with",
        "SUID" : 80755,
        "selected" : false,
        "Count_normalized" : 5.94
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80690",
        "source" : "80688",
        "target" : "80384",
        "shared_name" : "CRISPR-Cas9 WED domain (interacts with) HNH endonuclease",
        "shared_interaction" : "interacts with",
        "name" : "CRISPR-Cas9 WED domain (interacts with) HNH endonuclease",
        "interaction" : "interacts with",
        "SUID" : 80690,
        "selected" : false,
        "Count_normalized" : 6.16
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "84723",
        "source" : "80688",
        "target" : "80412",
        "shared_name" : "CRISPR-Cas9 WED domain (interacts with) Cas9 alpha-helical lobe domain",
        "shared_interaction" : "interacts with",
        "name" : "CRISPR-Cas9 WED domain (interacts with) Cas9 alpha-helical lobe domain",
        "interaction" : "interacts with",
        "SUID" : 84723,
        "selected" : false,
        "Count_normalized" : 4.25
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80595",
        "source" : "80558",
        "target" : "80593",
        "shared_name" : "PAS fold (interacts with) Response regulator receiver domain",
        "shared_interaction" : "interacts with",
        "name" : "PAS fold (interacts with) Response regulator receiver domain",
        "interaction" : "interacts with",
        "SUID" : 80595,
        "selected" : false,
        "Count_normalized" : 6.2
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81367",
        "source" : "80302",
        "target" : "80407",
        "shared_name" : "HD domain (interacts with) Helicase conserved C-terminal domain",
        "shared_interaction" : "interacts with",
        "name" : "HD domain (interacts with) Helicase conserved C-terminal domain",
        "interaction" : "interacts with",
        "SUID" : 81367,
        "selected" : false,
        "Count_normalized" : 5.77
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80304",
        "source" : "80300",
        "target" : "80302",
        "shared_name" : "Csm1 subunit domain B (interacts with) HD domain",
        "shared_interaction" : "interacts with",
        "name" : "Csm1 subunit domain B (interacts with) HD domain",
        "interaction" : "interacts with",
        "SUID" : 80304,
        "selected" : false,
        "Count_normalized" : 7.04
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80560",
        "source" : "80556",
        "target" : "80558",
        "shared_name" : "PAS domain (interacts with) PAS fold",
        "shared_interaction" : "interacts with",
        "name" : "PAS domain (interacts with) PAS fold",
        "interaction" : "interacts with",
        "SUID" : 80560,
        "selected" : false,
        "Count_normalized" : 6.21
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80728",
        "source" : "80556",
        "target" : "80593",
        "shared_name" : "PAS domain (interacts with) Response regulator receiver domain",
        "shared_interaction" : "interacts with",
        "name" : "PAS domain (interacts with) Response regulator receiver domain",
        "interaction" : "interacts with",
        "SUID" : 80728,
        "selected" : false,
        "Count_normalized" : 5.92
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81867",
        "source" : "80549",
        "target" : "81865",
        "shared_name" : "Choline-binding repeat (interacts with) N-acetylmuramoyl-L-alanine amidase",
        "shared_interaction" : "interacts with",
        "name" : "Choline-binding repeat (interacts with) N-acetylmuramoyl-L-alanine amidase",
        "interaction" : "interacts with",
        "SUID" : 81867,
        "selected" : false,
        "Count_normalized" : 3.69
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80553",
        "source" : "80549",
        "target" : "80551",
        "shared_name" : "Choline-binding repeat (interacts with) Putative cell wall binding repeat",
        "shared_interaction" : "interacts with",
        "name" : "Choline-binding repeat (interacts with) Putative cell wall binding repeat",
        "interaction" : "interacts with",
        "SUID" : 80553,
        "selected" : false,
        "Count_normalized" : 5.48
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82801",
        "source" : "80549",
        "target" : "81735",
        "shared_name" : "Choline-binding repeat (interacts with) Subtilase family",
        "shared_interaction" : "interacts with",
        "name" : "Choline-binding repeat (interacts with) Subtilase family",
        "interaction" : "interacts with",
        "SUID" : 82801,
        "selected" : false,
        "Count_normalized" : 3.66
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81430",
        "source" : "80549",
        "target" : "81428",
        "shared_name" : "Choline-binding repeat (interacts with) Y_Y_Y domain",
        "shared_interaction" : "interacts with",
        "name" : "Choline-binding repeat (interacts with) Y_Y_Y domain",
        "interaction" : "interacts with",
        "SUID" : 81430,
        "selected" : false,
        "Count_normalized" : 3.71
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80429",
        "source" : "80422",
        "target" : "80427",
        "shared_name" : "Probable transposase (interacts with) Putative transposase DNA-binding domain",
        "shared_interaction" : "interacts with",
        "name" : "Probable transposase (interacts with) Putative transposase DNA-binding domain",
        "interaction" : "interacts with",
        "SUID" : 80429,
        "selected" : false,
        "Count_normalized" : 6.28
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "83182",
        "source" : "81187",
        "target" : "80386",
        "shared_name" : "RRXRR protein (interacts with) RuvC endonuclease subdomain 3",
        "shared_interaction" : "interacts with",
        "name" : "RRXRR protein (interacts with) RuvC endonuclease subdomain 3",
        "interaction" : "interacts with",
        "SUID" : 83182,
        "selected" : false,
        "Count_normalized" : 4.71
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80432",
        "source" : "80420",
        "target" : "80427",
        "shared_name" : "Helix-turn-helix domain (interacts with) Putative transposase DNA-binding domain",
        "shared_interaction" : "interacts with",
        "name" : "Helix-turn-helix domain (interacts with) Putative transposase DNA-binding domain",
        "interaction" : "interacts with",
        "SUID" : 80432,
        "selected" : false,
        "Count_normalized" : 5.97
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80424",
        "source" : "80420",
        "target" : "80422",
        "shared_name" : "Helix-turn-helix domain (interacts with) Probable transposase",
        "shared_interaction" : "interacts with",
        "name" : "Helix-turn-helix domain (interacts with) Probable transposase",
        "interaction" : "interacts with",
        "SUID" : 80424,
        "selected" : false,
        "Count_normalized" : 5.91
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82169",
        "source" : "80420",
        "target" : "80738",
        "shared_name" : "Helix-turn-helix domain (interacts with) Integrase core domain",
        "shared_interaction" : "interacts with",
        "name" : "Helix-turn-helix domain (interacts with) Integrase core domain",
        "interaction" : "interacts with",
        "SUID" : 82169,
        "selected" : false,
        "Count_normalized" : 3.83
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80678",
        "source" : "80676",
        "target" : "80314",
        "shared_name" : "Centromere-binding protein HTH domain (interacts with) ParB/Sulfiredoxin domain",
        "shared_interaction" : "interacts with",
        "name" : "Centromere-binding protein HTH domain (interacts with) ParB/Sulfiredoxin domain",
        "interaction" : "interacts with",
        "SUID" : 80678,
        "selected" : false,
        "Count_normalized" : 4.66
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81146",
        "source" : "80676",
        "target" : "80312",
        "shared_name" : "Centromere-binding protein HTH domain (interacts with) HTH domain found in ParB protein",
        "shared_interaction" : "interacts with",
        "name" : "Centromere-binding protein HTH domain (interacts with) HTH domain found in ParB protein",
        "interaction" : "interacts with",
        "SUID" : 81146,
        "selected" : false,
        "Count_normalized" : 3.76
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81845",
        "source" : "81182",
        "target" : "80407",
        "shared_name" : "CRISPR-associated protein (Cas_Cas2CT1978) (interacts with) Helicase conserved C-terminal domain",
        "shared_interaction" : "interacts with",
        "name" : "CRISPR-associated protein (Cas_Cas2CT1978) (interacts with) Helicase conserved C-terminal domain",
        "interaction" : "interacts with",
        "SUID" : 81845,
        "selected" : false,
        "Count_normalized" : 4.14
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81184",
        "source" : "81182",
        "target" : "80405",
        "shared_name" : "CRISPR-associated protein (Cas_Cas2CT1978) (interacts with) DEAD/DEAH box helicase",
        "shared_interaction" : "interacts with",
        "name" : "CRISPR-associated protein (Cas_Cas2CT1978) (interacts with) DEAD/DEAH box helicase",
        "interaction" : "interacts with",
        "SUID" : 81184,
        "selected" : false,
        "Count_normalized" : 4.42
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80959",
        "source" : "80796",
        "target" : "80483",
        "shared_name" : "RNase H-like domain found in reverse transcriptase (interacts with) Reverse transcriptase (RNA-dependent DNA polymerase)",
        "shared_interaction" : "interacts with",
        "name" : "RNase H-like domain found in reverse transcriptase (interacts with) Reverse transcriptase (RNA-dependent DNA polymerase)",
        "interaction" : "interacts with",
        "SUID" : 80959,
        "selected" : false,
        "Count_normalized" : 4.17
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "84905",
        "source" : "80412",
        "target" : "80783",
        "shared_name" : "Cas9 alpha-helical lobe domain (interacts with) Topo homolgy domain in CRISPR-associated endonuclease Cas9",
        "shared_interaction" : "interacts with",
        "name" : "Cas9 alpha-helical lobe domain (interacts with) Topo homolgy domain in CRISPR-associated endonuclease Cas9",
        "interaction" : "interacts with",
        "SUID" : 84905,
        "selected" : false,
        "Count_normalized" : 4.13
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80417",
        "source" : "80412",
        "target" : "80386",
        "shared_name" : "Cas9 alpha-helical lobe domain (interacts with) RuvC endonuclease subdomain 3",
        "shared_interaction" : "interacts with",
        "name" : "Cas9 alpha-helical lobe domain (interacts with) RuvC endonuclease subdomain 3",
        "interaction" : "interacts with",
        "SUID" : 80417,
        "selected" : false,
        "Count_normalized" : 7.33
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80414",
        "source" : "80412",
        "target" : "80384",
        "shared_name" : "Cas9 alpha-helical lobe domain (interacts with) HNH endonuclease",
        "shared_interaction" : "interacts with",
        "name" : "Cas9 alpha-helical lobe domain (interacts with) HNH endonuclease",
        "interaction" : "interacts with",
        "SUID" : 80414,
        "selected" : false,
        "Count_normalized" : 7.48
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82075",
        "source" : "82073",
        "target" : "80556",
        "shared_name" : "Domain of unknown function (DUF4118) (interacts with) PAS domain",
        "shared_interaction" : "interacts with",
        "name" : "Domain of unknown function (DUF4118) (interacts with) PAS domain",
        "interaction" : "interacts with",
        "SUID" : 82075,
        "selected" : false,
        "Count_normalized" : 3.74
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82737",
        "source" : "82073",
        "target" : "80558",
        "shared_name" : "Domain of unknown function (DUF4118) (interacts with) PAS fold",
        "shared_interaction" : "interacts with",
        "name" : "Domain of unknown function (DUF4118) (interacts with) PAS fold",
        "interaction" : "interacts with",
        "SUID" : 82737,
        "selected" : false,
        "Count_normalized" : 3.71
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81631",
        "source" : "80407",
        "target" : "81504",
        "shared_name" : "Helicase conserved C-terminal domain (interacts with) WYL domain",
        "shared_interaction" : "interacts with",
        "name" : "Helicase conserved C-terminal domain (interacts with) WYL domain",
        "interaction" : "interacts with",
        "SUID" : 81631,
        "selected" : false,
        "Count_normalized" : 4.56
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81313",
        "source" : "80405",
        "target" : "81172",
        "shared_name" : "DEAD/DEAH box helicase (interacts with) Helicase C-terminal domain",
        "shared_interaction" : "interacts with",
        "name" : "DEAD/DEAH box helicase (interacts with) Helicase C-terminal domain",
        "interaction" : "interacts with",
        "SUID" : 81313,
        "selected" : false,
        "Count_normalized" : 4.23
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81718",
        "source" : "80405",
        "target" : "81504",
        "shared_name" : "DEAD/DEAH box helicase (interacts with) WYL domain",
        "shared_interaction" : "interacts with",
        "name" : "DEAD/DEAH box helicase (interacts with) WYL domain",
        "interaction" : "interacts with",
        "SUID" : 81718,
        "selected" : false,
        "Count_normalized" : 4.6
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80941",
        "source" : "80405",
        "target" : "80302",
        "shared_name" : "DEAD/DEAH box helicase (interacts with) HD domain",
        "shared_interaction" : "interacts with",
        "name" : "DEAD/DEAH box helicase (interacts with) HD domain",
        "interaction" : "interacts with",
        "SUID" : 80941,
        "selected" : false,
        "Count_normalized" : 6.04
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80409",
        "source" : "80405",
        "target" : "80407",
        "shared_name" : "DEAD/DEAH box helicase (interacts with) Helicase conserved C-terminal domain",
        "shared_interaction" : "interacts with",
        "name" : "DEAD/DEAH box helicase (interacts with) Helicase conserved C-terminal domain",
        "interaction" : "interacts with",
        "SUID" : 80409,
        "selected" : false,
        "Count_normalized" : 7.98
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "84902",
        "source" : "80788",
        "target" : "80412",
        "shared_name" : "Cas9 C-terminal domain (interacts with) Cas9 alpha-helical lobe domain",
        "shared_interaction" : "interacts with",
        "name" : "Cas9 C-terminal domain (interacts with) Cas9 alpha-helical lobe domain",
        "interaction" : "interacts with",
        "SUID" : 84902,
        "selected" : false,
        "Count_normalized" : 4.13
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80793",
        "source" : "80788",
        "target" : "80783",
        "shared_name" : "Cas9 C-terminal domain (interacts with) Topo homolgy domain in CRISPR-associated endonuclease Cas9",
        "shared_interaction" : "interacts with",
        "name" : "Cas9 C-terminal domain (interacts with) Topo homolgy domain in CRISPR-associated endonuclease Cas9",
        "interaction" : "interacts with",
        "SUID" : 80793,
        "selected" : false,
        "Count_normalized" : 4.69
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81042",
        "source" : "80788",
        "target" : "80384",
        "shared_name" : "Cas9 C-terminal domain (interacts with) HNH endonuclease",
        "shared_interaction" : "interacts with",
        "name" : "Cas9 C-terminal domain (interacts with) HNH endonuclease",
        "interaction" : "interacts with",
        "SUID" : 81042,
        "selected" : false,
        "Count_normalized" : 5.67
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81039",
        "source" : "80788",
        "target" : "80386",
        "shared_name" : "Cas9 C-terminal domain (interacts with) RuvC endonuclease subdomain 3",
        "shared_interaction" : "interacts with",
        "name" : "Cas9 C-terminal domain (interacts with) RuvC endonuclease subdomain 3",
        "interaction" : "interacts with",
        "SUID" : 81039,
        "selected" : false,
        "Count_normalized" : 5.53
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81112",
        "source" : "80914",
        "target" : "80650",
        "shared_name" : "Histidine kinase (interacts with) Tetratricopeptide repeat",
        "shared_interaction" : "interacts with",
        "name" : "Histidine kinase (interacts with) Tetratricopeptide repeat",
        "interaction" : "interacts with",
        "SUID" : 81112,
        "selected" : false,
        "Count_normalized" : 4.29
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80616",
        "source" : "80530",
        "target" : "80614",
        "shared_name" : "Coiled stalk of trimeric autotransporter adhesin (interacts with) YadA head domain repeat (2 copies)",
        "shared_interaction" : "interacts with",
        "name" : "Coiled stalk of trimeric autotransporter adhesin (interacts with) YadA head domain repeat (2 copies)",
        "interaction" : "interacts with",
        "SUID" : 80616,
        "selected" : false,
        "Count_normalized" : 4.66
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80583",
        "source" : "80530",
        "target" : "80581",
        "shared_name" : "Coiled stalk of trimeric autotransporter adhesin (interacts with) Extended Signal Peptide of Type V secretion system",
        "shared_interaction" : "interacts with",
        "name" : "Coiled stalk of trimeric autotransporter adhesin (interacts with) Extended Signal Peptide of Type V secretion system",
        "interaction" : "interacts with",
        "SUID" : 80583,
        "selected" : false,
        "Count_normalized" : 4.77
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81088",
        "source" : "80530",
        "target" : "81086",
        "shared_name" : "Coiled stalk of trimeric autotransporter adhesin (interacts with) PE family",
        "shared_interaction" : "interacts with",
        "name" : "Coiled stalk of trimeric autotransporter adhesin (interacts with) PE family",
        "interaction" : "interacts with",
        "SUID" : 81088,
        "selected" : false,
        "Count_normalized" : 3.58
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80534",
        "source" : "80530",
        "target" : "80532",
        "shared_name" : "Coiled stalk of trimeric autotransporter adhesin (interacts with) YadA-like membrane anchor domain",
        "shared_interaction" : "interacts with",
        "name" : "Coiled stalk of trimeric autotransporter adhesin (interacts with) YadA-like membrane anchor domain",
        "interaction" : "interacts with",
        "SUID" : 80534,
        "selected" : false,
        "Count_normalized" : 5.07
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81030",
        "source" : "80530",
        "target" : "81028",
        "shared_name" : "Coiled stalk of trimeric autotransporter adhesin (interacts with) PGRS repeats",
        "shared_interaction" : "interacts with",
        "name" : "Coiled stalk of trimeric autotransporter adhesin (interacts with) PGRS repeats",
        "interaction" : "interacts with",
        "SUID" : 81030,
        "selected" : false,
        "Count_normalized" : 3.58
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81478",
        "source" : "80530",
        "target" : "81476",
        "shared_name" : "Coiled stalk of trimeric autotransporter adhesin (interacts with) S-layer homology domain",
        "shared_interaction" : "interacts with",
        "name" : "Coiled stalk of trimeric autotransporter adhesin (interacts with) S-layer homology domain",
        "interaction" : "interacts with",
        "SUID" : 81478,
        "selected" : false,
        "Count_normalized" : 3.78
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "84908",
        "source" : "80781",
        "target" : "80412",
        "shared_name" : "CRISPR-associated endonuclease Cas9 beta-hairpin domain (interacts with) Cas9 alpha-helical lobe domain",
        "shared_interaction" : "interacts with",
        "name" : "CRISPR-associated endonuclease Cas9 beta-hairpin domain (interacts with) Cas9 alpha-helical lobe domain",
        "interaction" : "interacts with",
        "SUID" : 84908,
        "selected" : false,
        "Count_normalized" : 4.13
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81045",
        "source" : "80781",
        "target" : "80384",
        "shared_name" : "CRISPR-associated endonuclease Cas9 beta-hairpin domain (interacts with) HNH endonuclease",
        "shared_interaction" : "interacts with",
        "name" : "CRISPR-associated endonuclease Cas9 beta-hairpin domain (interacts with) HNH endonuclease",
        "interaction" : "interacts with",
        "SUID" : 81045,
        "selected" : false,
        "Count_normalized" : 5.67
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80790",
        "source" : "80781",
        "target" : "80788",
        "shared_name" : "CRISPR-associated endonuclease Cas9 beta-hairpin domain (interacts with) Cas9 C-terminal domain",
        "shared_interaction" : "interacts with",
        "name" : "CRISPR-associated endonuclease Cas9 beta-hairpin domain (interacts with) Cas9 C-terminal domain",
        "interaction" : "interacts with",
        "SUID" : 80790,
        "selected" : false,
        "Count_normalized" : 4.69
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80785",
        "source" : "80781",
        "target" : "80783",
        "shared_name" : "CRISPR-associated endonuclease Cas9 beta-hairpin domain (interacts with) Topo homolgy domain in CRISPR-associated endonuclease Cas9",
        "shared_interaction" : "interacts with",
        "name" : "CRISPR-associated endonuclease Cas9 beta-hairpin domain (interacts with) Topo homolgy domain in CRISPR-associated endonuclease Cas9",
        "interaction" : "interacts with",
        "SUID" : 80785,
        "selected" : false,
        "Count_normalized" : 4.69
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81033",
        "source" : "80781",
        "target" : "80386",
        "shared_name" : "CRISPR-associated endonuclease Cas9 beta-hairpin domain (interacts with) RuvC endonuclease subdomain 3",
        "shared_interaction" : "interacts with",
        "name" : "CRISPR-associated endonuclease Cas9 beta-hairpin domain (interacts with) RuvC endonuclease subdomain 3",
        "interaction" : "interacts with",
        "SUID" : 81033,
        "selected" : false,
        "Count_normalized" : 5.53
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "84274",
        "source" : "82057",
        "target" : "80846",
        "shared_name" : "Bacterial Ig domain (interacts with) BspA type Leucine rich repeat region (6 copies)",
        "shared_interaction" : "interacts with",
        "name" : "Bacterial Ig domain (interacts with) BspA type Leucine rich repeat region (6 copies)",
        "interaction" : "interacts with",
        "SUID" : 84274,
        "selected" : false,
        "Count_normalized" : 3.66
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80905",
        "source" : "80903",
        "target" : "80738",
        "shared_name" : "HTH-like domain (interacts with) Integrase core domain",
        "shared_interaction" : "interacts with",
        "name" : "HTH-like domain (interacts with) Integrase core domain",
        "interaction" : "interacts with",
        "SUID" : 80905,
        "selected" : false,
        "Count_normalized" : 3.76
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80605",
        "source" : "80520",
        "target" : "80326",
        "shared_name" : "Cache domain (interacts with) HAMP domain",
        "shared_interaction" : "interacts with",
        "name" : "Cache domain (interacts with) HAMP domain",
        "interaction" : "interacts with",
        "SUID" : 80605,
        "selected" : false,
        "Count_normalized" : 5.21
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80522",
        "source" : "80520",
        "target" : "80328",
        "shared_name" : "Cache domain (interacts with) Methyl-accepting chemotaxis protein (MCP) signalling domain",
        "shared_interaction" : "interacts with",
        "name" : "Cache domain (interacts with) Methyl-accepting chemotaxis protein (MCP) signalling domain",
        "interaction" : "interacts with",
        "SUID" : 80522,
        "selected" : false,
        "Count_normalized" : 5.34
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82199",
        "source" : "80520",
        "target" : "80314",
        "shared_name" : "Cache domain (interacts with) ParB/Sulfiredoxin domain",
        "shared_interaction" : "interacts with",
        "name" : "Cache domain (interacts with) ParB/Sulfiredoxin domain",
        "interaction" : "interacts with",
        "SUID" : 82199,
        "selected" : false,
        "Count_normalized" : 3.93
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80652",
        "source" : "80648",
        "target" : "80650",
        "shared_name" : "TPR repeat (interacts with) Tetratricopeptide repeat",
        "shared_interaction" : "interacts with",
        "name" : "TPR repeat (interacts with) Tetratricopeptide repeat",
        "interaction" : "interacts with",
        "SUID" : 80652,
        "selected" : false,
        "Count_normalized" : 4.84
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80773",
        "source" : "80771",
        "target" : "80314",
        "shared_name" : "KorB domain (interacts with) ParB/Sulfiredoxin domain",
        "shared_interaction" : "interacts with",
        "name" : "KorB domain (interacts with) ParB/Sulfiredoxin domain",
        "interaction" : "interacts with",
        "SUID" : 80773,
        "selected" : false,
        "Count_normalized" : 4.45
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81036",
        "source" : "80386",
        "target" : "80783",
        "shared_name" : "RuvC endonuclease subdomain 3 (interacts with) Topo homolgy domain in CRISPR-associated endonuclease Cas9",
        "shared_interaction" : "interacts with",
        "name" : "RuvC endonuclease subdomain 3 (interacts with) Topo homolgy domain in CRISPR-associated endonuclease Cas9",
        "interaction" : "interacts with",
        "SUID" : 81036,
        "selected" : false,
        "Count_normalized" : 5.53
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81048",
        "source" : "80384",
        "target" : "80783",
        "shared_name" : "HNH endonuclease (interacts with) Topo homolgy domain in CRISPR-associated endonuclease Cas9",
        "shared_interaction" : "interacts with",
        "name" : "HNH endonuclease (interacts with) Topo homolgy domain in CRISPR-associated endonuclease Cas9",
        "interaction" : "interacts with",
        "SUID" : 81048,
        "selected" : false,
        "Count_normalized" : 5.67
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80452",
        "source" : "80384",
        "target" : "80450",
        "shared_name" : "HNH endonuclease (interacts with) PAM-interacting domain of CRISPR-associated endonuclease Cas9",
        "shared_interaction" : "interacts with",
        "name" : "HNH endonuclease (interacts with) PAM-interacting domain of CRISPR-associated endonuclease Cas9",
        "interaction" : "interacts with",
        "SUID" : 80452,
        "selected" : false,
        "Count_normalized" : 7.32
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80447",
        "source" : "80384",
        "target" : "80445",
        "shared_name" : "HNH endonuclease (interacts with) REC lobe of CRISPR-associated endonuclease Cas9",
        "shared_interaction" : "interacts with",
        "name" : "HNH endonuclease (interacts with) REC lobe of CRISPR-associated endonuclease Cas9",
        "interaction" : "interacts with",
        "SUID" : 80447,
        "selected" : false,
        "Count_normalized" : 7.47
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81189",
        "source" : "80384",
        "target" : "81187",
        "shared_name" : "HNH endonuclease (interacts with) RRXRR protein",
        "shared_interaction" : "interacts with",
        "name" : "HNH endonuclease (interacts with) RRXRR protein",
        "interaction" : "interacts with",
        "SUID" : 81189,
        "selected" : false,
        "Count_normalized" : 5.2
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81125",
        "source" : "80760",
        "target" : "80859",
        "shared_name" : "Domain of unknown function (DUF4143) (interacts with) UvrD-like helicase C-terminal domain",
        "shared_interaction" : "interacts with",
        "name" : "Domain of unknown function (DUF4143) (interacts with) UvrD-like helicase C-terminal domain",
        "interaction" : "interacts with",
        "SUID" : 81125,
        "selected" : false,
        "Count_normalized" : 3.89
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81341",
        "source" : "80760",
        "target" : "80861",
        "shared_name" : "Domain of unknown function (DUF4143) (interacts with) UvrD/REP helicase N-terminal domain",
        "shared_interaction" : "interacts with",
        "name" : "Domain of unknown function (DUF4143) (interacts with) UvrD/REP helicase N-terminal domain",
        "interaction" : "interacts with",
        "SUID" : 81341,
        "selected" : false,
        "Count_normalized" : 3.58
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "84694",
        "source" : "80758",
        "target" : "80481",
        "shared_name" : "AAA domain (interacts with) CRISPR associated protein Cas1",
        "shared_interaction" : "interacts with",
        "name" : "AAA domain (interacts with) CRISPR associated protein Cas1",
        "interaction" : "interacts with",
        "SUID" : 84694,
        "selected" : false,
        "Count_normalized" : 3.87
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "84427",
        "source" : "80758",
        "target" : "80483",
        "shared_name" : "AAA domain (interacts with) Reverse transcriptase (RNA-dependent DNA polymerase)",
        "shared_interaction" : "interacts with",
        "name" : "AAA domain (interacts with) Reverse transcriptase (RNA-dependent DNA polymerase)",
        "interaction" : "interacts with",
        "SUID" : 84427,
        "selected" : false,
        "Count_normalized" : 3.99
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80762",
        "source" : "80758",
        "target" : "80760",
        "shared_name" : "AAA domain (interacts with) Domain of unknown function (DUF4143)",
        "shared_interaction" : "interacts with",
        "name" : "AAA domain (interacts with) Domain of unknown function (DUF4143)",
        "interaction" : "interacts with",
        "SUID" : 80762,
        "selected" : false,
        "Count_normalized" : 4.69
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81518",
        "source" : "80758",
        "target" : "80861",
        "shared_name" : "AAA domain (interacts with) UvrD/REP helicase N-terminal domain",
        "shared_interaction" : "interacts with",
        "name" : "AAA domain (interacts with) UvrD/REP helicase N-terminal domain",
        "interaction" : "interacts with",
        "SUID" : 81518,
        "selected" : false,
        "Count_normalized" : 3.97
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80990",
        "source" : "80758",
        "target" : "80859",
        "shared_name" : "AAA domain (interacts with) UvrD-like helicase C-terminal domain",
        "shared_interaction" : "interacts with",
        "name" : "AAA domain (interacts with) UvrD-like helicase C-terminal domain",
        "interaction" : "interacts with",
        "SUID" : 80990,
        "selected" : false,
        "Count_normalized" : 4.51
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81523",
        "source" : "81521",
        "target" : "80314",
        "shared_name" : "Helix-turn-helix (interacts with) ParB/Sulfiredoxin domain",
        "shared_interaction" : "interacts with",
        "name" : "Helix-turn-helix (interacts with) ParB/Sulfiredoxin domain",
        "interaction" : "interacts with",
        "SUID" : 81523,
        "selected" : false,
        "Count_normalized" : 4.08
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80810",
        "source" : "80498",
        "target" : "80384",
        "shared_name" : "Bridge helix of CRISPR-associated endonuclease Cas9 (interacts with) HNH endonuclease",
        "shared_interaction" : "interacts with",
        "name" : "Bridge helix of CRISPR-associated endonuclease Cas9 (interacts with) HNH endonuclease",
        "interaction" : "interacts with",
        "SUID" : 80810,
        "selected" : false,
        "Count_normalized" : 6.29
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80500",
        "source" : "80498",
        "target" : "80445",
        "shared_name" : "Bridge helix of CRISPR-associated endonuclease Cas9 (interacts with) REC lobe of CRISPR-associated endonuclease Cas9",
        "shared_interaction" : "interacts with",
        "name" : "Bridge helix of CRISPR-associated endonuclease Cas9 (interacts with) REC lobe of CRISPR-associated endonuclease Cas9",
        "interaction" : "interacts with",
        "SUID" : 80500,
        "selected" : false,
        "Count_normalized" : 6.05
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82489",
        "source" : "80498",
        "target" : "80450",
        "shared_name" : "Bridge helix of CRISPR-associated endonuclease Cas9 (interacts with) PAM-interacting domain of CRISPR-associated endonuclease Cas9",
        "shared_interaction" : "interacts with",
        "name" : "Bridge helix of CRISPR-associated endonuclease Cas9 (interacts with) PAM-interacting domain of CRISPR-associated endonuclease Cas9",
        "interaction" : "interacts with",
        "SUID" : 82489,
        "selected" : false,
        "Count_normalized" : 4.58
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81208",
        "source" : "80498",
        "target" : "80386",
        "shared_name" : "Bridge helix of CRISPR-associated endonuclease Cas9 (interacts with) RuvC endonuclease subdomain 3",
        "shared_interaction" : "interacts with",
        "name" : "Bridge helix of CRISPR-associated endonuclease Cas9 (interacts with) RuvC endonuclease subdomain 3",
        "interaction" : "interacts with",
        "SUID" : 81208,
        "selected" : false,
        "Count_normalized" : 5.82
      },
      "selected" : false
    } ]
  }
}}